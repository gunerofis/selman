import { BRAND } from "./brand";

export function pageTitle(page?: string) {
  return page ? `${page} — ${BRAND.name}` : `${BRAND.name} — düzen ürünleri`;
}

export function pageHead({
  title,
  description,
  path,
}: {
  title: string;
  description?: string;
  path: string;
}) {
  return {
    meta: [
      { title: pageTitle(title) },
      { name: "description", content: description ?? BRAND.tagline },
    ],
    links: [{ rel: "canonical", href: path }],
  };
}
