import { Link } from "@tanstack/react-router";
import { CATEGORIES, COLORS, PASTEL, SERIES, productSlug, type ColorId, type Product } from "@/lib/products";
import { useCart } from "@/lib/cart";
import { formatPrice } from "@/lib/utils";
import { WishButton } from "@/components/wish-button";
import { Button } from "@/components/ui/button";

export function ProductCard({
  product,
  color,
}: {
  product: Product;
  color?: ColorId;
}) {
  const cat = CATEGORIES.find((c) => c.id === product.category);
  const series = SERIES.find((s) => s.id === product.series);
  const add = useCart((s) => s.add);
  const chosen = color ?? "espresso";
  const colorName = COLORS.find((c) => c.id === chosen)?.name;
  const wash = color ? PASTEL[color] : undefined;

  return (
    <article className="group flex flex-col">
      <div
        className="relative border border-dashed border-border bg-bg-wash transition-colors duration-200 group-hover:border-fg"
        style={wash ? { backgroundColor: wash } : undefined}
      >
        <Link
          to="/urun/$sku"
          params={{ sku: productSlug(product) }}
          search={color ? { renk: color } : undefined}
          className="block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <img
            src={product.image}
            alt={product.name}
            className="aspect-square w-full object-contain p-3 transition-opacity duration-200 group-hover:opacity-90"
          />
        </Link>
        <span className="absolute top-2 left-2 font-mono text-xs text-fg-muted">
          {product.sku}
        </span>
        <WishButton sku={product.sku} className="absolute top-1 right-1" />
      </div>
      <div className="flex flex-1 flex-col gap-1 border-x border-b border-dashed border-border bg-bg-elevated px-3 pt-3 pb-3">
        <p className="font-mono text-xs tracking-wide text-fg-muted uppercase">
          {series?.name ?? cat?.name}
        </p>
        <Link
          to="/urun/$sku"
          params={{ sku: productSlug(product) }}
          search={color ? { renk: color } : undefined}
        >
          <h3 className="font-display text-lg leading-snug text-fg hover:text-taba">
            {product.name}
          </h3>
        </Link>
        <p className="font-mono text-sm tabular-nums">{formatPrice(product.price)}</p>
        <div className="mt-2 flex items-center gap-1" aria-hidden>
          {COLORS.map((c) => (
            <span
              key={c.id}
              title={c.name}
              className="size-2.5 border border-border-strong"
              style={{ backgroundColor: c.swatch }}
            />
          ))}
        </div>
        {color ? (
          <p className="font-mono text-xs text-fg-muted">{colorName}</p>
        ) : null}
        <Button
          variant="outline"
          size="sm"
          className="mt-3 w-full"
          onClick={() => add(product.sku, chosen, 1)}
        >
          Sepete ekle
        </Button>
      </div>
    </article>
  );
}
