import { create } from "zustand";
import { persist } from "zustand/middleware";
import { getProduct, type Product } from "./products";

type PrefsState = {
  wishlist: string[];
  recent: string[];
  toggleWish: (sku: string) => void;
  pushRecent: (sku: string) => void;
};

export const usePrefs = create<PrefsState>()(
  persist(
    (set, get) => ({
      wishlist: [],
      recent: [],
      toggleWish: (sku) => {
        const cur = get().wishlist;
        set({
          wishlist: cur.includes(sku) ? cur.filter((s) => s !== sku) : [sku, ...cur],
        });
      },
      pushRecent: (sku) => {
        set({
          recent: [sku, ...get().recent.filter((s) => s !== sku)].slice(0, 8),
        });
      },
    }),
    { name: "sweb-prefs" },
  ),
);

export function wishedProducts(skus: string[]) {
  return skus.map(getProduct).filter((p): p is Product => p != null);
}
