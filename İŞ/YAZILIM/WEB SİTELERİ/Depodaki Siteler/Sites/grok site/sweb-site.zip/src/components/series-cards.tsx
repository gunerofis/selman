import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import {
  SERIES,
  productsBySeries,
  seriesTotal,
  type ColorId,
  type SeriesId,
} from "@/lib/products";
import { useCart } from "@/lib/cart";
import { formatPrice } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export function SeriesCards({ color }: { color?: ColorId }) {
  return (
    <div className="grid gap-4 md:grid-cols-3">
      {SERIES.map((s) => (
        <SeriesCard key={s.id} id={s.id} color={color} />
      ))}
    </div>
  );
}

export function SeriesCard({ id, color }: { id: SeriesId; color?: ColorId }) {
  const series = SERIES.find((s) => s.id === id);
  const items = productsBySeries(id);
  const total = seriesTotal(id);
  const addMany = useCart((s) => s.addMany);
  const chosen = color ?? "espresso";
  if (!series) return null;

  return (
    <article className="flex flex-col border border-dashed border-border bg-bg-elevated">
      <Link
        to="/koleksiyon"
        search={{ kategori: "ofis", seri: id }}
        className="block bg-bg-wash"
      >
        <img
          src={series.image}
          alt={series.name}
          className="aspect-[3/2] w-full object-contain p-3"
        />
      </Link>
      <div className="grid grid-cols-6 gap-px border-t border-dashed border-border bg-border">
        {items.slice(0, 6).map((p) => (
          <img
            key={p.sku}
            src={p.image}
            alt=""
            className="aspect-square w-full bg-bg-wash object-contain p-1"
          />
        ))}
      </div>
      <div className="flex flex-1 flex-col gap-2 px-4 pt-3 pb-4">
        <p className="font-mono text-xs tracking-wide text-fg-muted uppercase">Ofis seti</p>
        <h3 className="font-display text-xl leading-snug">{series.name}</h3>
        <p className="text-sm text-fg-muted">
          {series.blurb} {items.length} parça, tek renk kit.
        </p>
        <p className="mt-auto font-mono text-sm tabular-nums">{formatPrice(total)}</p>
        <div className="mt-2 flex flex-col gap-2">
          <Button
            className="w-full"
            onClick={() => {
              addMany(
                items.map((p) => p.sku),
                chosen,
              );
              toast.success(`${items.length} parça sepete eklendi`);
            }}
          >
            Seti sepete ekle
          </Button>
          <Link
            to="/koleksiyon"
            search={{ kategori: "ofis", seri: id }}
            className="block"
          >
            <Button variant="outline" className="w-full">
              Parçaları gör
            </Button>
          </Link>
        </div>
      </div>
    </article>
  );
}
