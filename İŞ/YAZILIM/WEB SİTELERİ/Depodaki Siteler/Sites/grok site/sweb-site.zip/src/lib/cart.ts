import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  FREE_SHIPPING_FROM,
  SHIPPING_FEE,
  getProduct,
  type ColorId,
} from "./products";

export type CartLine = {
  sku: string;
  color: ColorId;
  qty: number;
};

type CartState = {
  lines: CartLine[];
  drawerOpen: boolean;
  add: (sku: string, color: ColorId, qty?: number, shouldOpen?: boolean) => void;
  addMany: (skus: string[], color: ColorId, shouldOpen?: boolean) => void;
  setQty: (sku: string, color: ColorId, qty: number) => void;
  remove: (sku: string, color: ColorId) => void;
  clear: () => void;
  openDrawer: () => void;
  closeDrawer: () => void;
};

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      lines: [],
      drawerOpen: false,
      add: (sku, color, qty = 1, shouldOpen = true) => {
        const lines = [...get().lines];
        const i = lines.findIndex((l) => l.sku === sku && l.color === color);
        if (i >= 0) lines[i] = { ...lines[i], qty: lines[i].qty + qty };
        else lines.push({ sku, color, qty });
        set({ lines, drawerOpen: shouldOpen ? true : get().drawerOpen });
      },
      addMany: (skus, color, shouldOpen = true) => {
        const lines = [...get().lines];
        for (const sku of skus) {
          const i = lines.findIndex((l) => l.sku === sku && l.color === color);
          if (i >= 0) lines[i] = { ...lines[i], qty: lines[i].qty + 1 };
          else lines.push({ sku, color, qty: 1 });
        }
        set({ lines, drawerOpen: shouldOpen ? true : get().drawerOpen });
      },
      setQty: (sku, color, qty) => {
        if (qty < 1) {
          set({ lines: get().lines.filter((l) => !(l.sku === sku && l.color === color)) });
          return;
        }
        set({
          lines: get().lines.map((l) =>
            l.sku === sku && l.color === color ? { ...l, qty } : l,
          ),
        });
      },
      remove: (sku, color) =>
        set({ lines: get().lines.filter((l) => !(l.sku === sku && l.color === color)) }),
      clear: () => set({ lines: [], drawerOpen: false }),
      openDrawer: () => set({ drawerOpen: true }),
      closeDrawer: () => set({ drawerOpen: false }),
    }),
    {
      name: "sweb-cart",
      partialize: (s) => ({ lines: s.lines }),
    },
  ),
);

export function cartCount(lines: CartLine[]) {
  return lines.reduce((n, l) => n + l.qty, 0);
}

export function cartSubtotal(lines: CartLine[]) {
  return lines.reduce((sum, l) => {
    const p = getProduct(l.sku);
    return sum + (p ? p.price * l.qty : 0);
  }, 0);
}

export function shippingFor(subtotal: number) {
  if (subtotal === 0) return 0;
  return subtotal >= FREE_SHIPPING_FROM ? 0 : SHIPPING_FEE;
}
