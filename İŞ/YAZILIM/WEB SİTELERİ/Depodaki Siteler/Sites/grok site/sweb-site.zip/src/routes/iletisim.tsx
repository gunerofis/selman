import { type FormEvent, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BRAND } from "@/lib/brand";
import { pageHead } from "@/lib/seo";
import { DemoNotice } from "@/components/demo-notice";

export const Route = createFileRoute("/iletisim")({
  component: Contact,
  head: () =>
    pageHead({
      title: "İletişim",
      description: "Atölyeye yazın. Bu önizlemede form gönderilmez.",
      path: "/iletisim",
    }),
});

function Contact() {
  const [sent, setSent] = useState(false);

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSent(true);
    toast.success("Önizleme: mesaj tarayıcıda kaldı, gönderilmedi.");
    e.currentTarget.reset();
  }

  return (
    <div className="mx-auto grid max-w-5xl gap-12 px-4 py-14 lg:grid-cols-2">
      <div>
        <p className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">İletişim</p>
        <h1 className="mt-3 font-display text-4xl sm:text-5xl">Atölyeye yazın.</h1>
        <p className="mt-4 max-w-prose text-sm leading-relaxed text-fg-muted">
          Sipariş, renk veya toptan için. Hafta içi {BRAND.hours} yanıtlarız.
        </p>
        <dl className="mt-8 space-y-4 text-sm">
          <div>
            <dt className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">E-posta</dt>
            <dd>
              <a href={`mailto:${BRAND.email}`} className="text-taba hover:underline">
                {BRAND.email}
              </a>
            </dd>
          </div>
          <div>
            <dt className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">Atölye</dt>
            <dd>{BRAND.atelier}</dd>
          </div>
          <div>
            <dt className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">Yanıt</dt>
            <dd>{BRAND.reply}</dd>
          </div>
          <div>
            <dt className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">Kargo</dt>
            <dd>5.000 ₺ üzeri yok · 3–5 iş günü</dd>
          </div>
        </dl>
      </div>
      <form
        onSubmit={onSubmit}
        className="flex flex-col gap-4 border border-dashed border-border bg-bg-elevated p-6"
      >
        <DemoNotice>Bu form tarayıcıda kalır, atölyeye gönderilmez.</DemoNotice>
        <label className="grid gap-1.5 text-sm">
          <span className="font-mono text-[11px] text-fg-muted">ad soyad</span>
          <Input name="name" required autoComplete="name" />
        </label>
        <label className="grid gap-1.5 text-sm">
          <span className="font-mono text-[11px] text-fg-muted">e-posta</span>
          <Input name="email" type="email" required autoComplete="email" placeholder="ad@firma.com" />
        </label>
        <label className="grid gap-1.5 text-sm">
          <span className="font-mono text-[11px] text-fg-muted">sipariş no</span>
          <Input name="order" />
        </label>
        <label className="grid gap-1.5 text-sm">
          <span className="font-mono text-[11px] text-fg-muted">mesaj</span>
          <textarea
            name="message"
            required
            rows={5}
            className="border border-border-strong bg-bg-elevated px-3 py-2 text-sm text-fg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
        </label>
        <label className="flex items-start gap-2 text-sm">
          <input type="checkbox" name="kvkk" required className="mt-1 size-4 shrink-0" />
          <span>
            <Link to="/kvkk" className="underline-offset-2 hover:underline">
              KVKK aydınlatmasını
            </Link>{" "}
            okudum.
          </span>
        </label>
        <div className="hidden" aria-hidden>
          <label>
            Bu alanı boş bırakın
            <input name="trap" tabIndex={-1} autoComplete="off" />
          </label>
        </div>
        <Button type="submit" size="lg">
          Mesaj gönder
        </Button>
        {sent ? (
          <p className="font-mono text-xs text-taba">Önizleme. Gönderilmedi.</p>
        ) : null}
      </form>
    </div>
  );
}
