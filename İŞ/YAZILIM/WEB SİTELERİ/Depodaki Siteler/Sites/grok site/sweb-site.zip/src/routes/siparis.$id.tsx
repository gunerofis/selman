import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { getColor, getProduct } from "@/lib/products";
import { pageHead } from "@/lib/seo";
import { formatPrice } from "@/lib/utils";
import type { ColorId } from "@/lib/products";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/siparis/$id")({
  component: OrderDone,
  head: ({ params }) =>
    pageHead({
      title: `Sipariş ${params.id}`,
      description: "Önizleme siparişi. Tahsilat yok.",
      path: `/siparis/${params.id}`,
    }),
});

type StoredOrder = {
  id: string;
  name: string;
  city: string;
  pay: string;
  total: number;
  items: { sku: string; color: ColorId; qty: number }[];
};

function OrderDone() {
  const { id } = Route.useParams();
  const [order, setOrder] = useState<StoredOrder | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("sweb-last-order");
      if (!raw) return;
      const parsed = JSON.parse(raw) as StoredOrder;
      if (parsed.id === id) setOrder(parsed);
    } catch {
      /* ignore */
    }
  }, [id]);

  return (
    <div className="mx-auto max-w-xl px-4 py-16 text-center">
      <p className="text-xs tracking-[0.28em] text-fg-muted uppercase">Sipariş alındı</p>
      <h1 className="mt-3 font-display text-5xl">Teşekkürler</h1>
      <p className="mt-4 text-sm text-fg-muted">
        Sipariş numaranız <span className="font-medium text-fg">{id}</span>
        {order ? ` · ${order.name}, ${order.city}` : ""}. Teslim 3–5 iş günü — bu
        kayıt tarayıcıda; atölyeye iletilmedi.
      </p>
      {order ? (
        <ul className="mt-8 divide-y divide-border border-y border-border text-left">
          {order.items.map((l) => {
            const p = getProduct(l.sku);
            const c = getColor(l.color);
            if (!p) return null;
            return (
              <li key={`${l.sku}-${l.color}`} className="flex justify-between py-3 text-sm">
                <span>
                  {p.name}
                  <span className="block text-xs text-fg-subtle">
                    {c?.name} × {l.qty}
                  </span>
                </span>
                <span className="tabular-nums">{formatPrice(p.price * l.qty)}</span>
              </li>
            );
          })}
        </ul>
      ) : null}
      {order ? (
        <p className="mt-4 text-sm">
          Toplam {formatPrice(order.total)} ·{" "}
          {order.pay === "havale" ? "Havale / EFT" : "Kapıda ödeme"}
        </p>
      ) : null}
      <Link to="/koleksiyon" className="mt-8 inline-block">
        <Button>Koleksiyona dön</Button>
      </Link>
    </div>
  );
}
