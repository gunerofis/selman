import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export function AppNotFound() {
  return (
    <div className="mx-auto flex min-h-80 max-w-lg flex-col items-center justify-center gap-4 px-4 py-20 text-center">
      <p className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">404</p>
      <h1 className="font-display text-4xl">Bu parça yok</h1>
      <p className="text-sm text-fg-muted">Sayfa taşınmış ya da kod hatalı olabilir.</p>
      <Link to="/koleksiyon">
        <Button>Koleksiyona dön</Button>
      </Link>
    </div>
  );
}
