import { createFileRoute, Link } from "@tanstack/react-router";
import { pageHead } from "@/lib/seo";
import { SeriesCards } from "@/components/series-cards";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/setler")({
  component: SetsPage,
  head: () =>
    pageHead({
      title: "Ofis setleri",
      description: "Kompakt, aksesuar, yönetici. Tek renk kit.",
      path: "/setler",
    }),
});

function SetsPage() {
  return (
    <div className="mx-auto max-w-[1400px] px-4 py-10">
      <p className="font-mono text-xs tracking-wide text-fg-muted uppercase">Ofis</p>
      <h1 className="mt-2 font-display text-4xl sm:text-5xl">Ofis setleri</h1>
      <p className="mt-3 max-w-xl text-sm text-fg-muted">
        Üç kit. Aynı renk, tek sepet. Parçalar ayrı da satılır.
      </p>
      <div className="mt-10">
        <SeriesCards />
      </div>
      <div className="mt-10">
        <Link to="/koleksiyon" search={{ kategori: "ofis" }}>
          <Button variant="outline">Tüm ofis parçaları</Button>
        </Link>
      </div>
    </div>
  );
}
