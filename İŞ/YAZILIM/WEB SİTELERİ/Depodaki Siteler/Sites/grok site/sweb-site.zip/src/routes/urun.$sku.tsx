import { useEffect, useState } from "react";
import { createFileRoute, Link, notFound, redirect } from "@tanstack/react-router";
import { Truck, RotateCcw, Droplets } from "lucide-react";
import {
  CATEGORIES,
  COLORS,
  FREE_SHIPPING_FROM,
  PASTEL,
  getColor,
  getProduct,
  getSeries,
  neighborsInCategory,
  productSlug,
  productsBySeries,
  relatedProducts,
  specGrams,
  type ColorId,
  type Product,
} from "@/lib/products";
import { pageHead } from "@/lib/seo";
import { useCart } from "@/lib/cart";
import { usePrefs } from "@/lib/prefs";
import { formatPrice } from "@/lib/utils";
import { ProductCard } from "@/components/product-card";
import { ColorSwatches } from "@/components/color-swatch";
import { QtyControl } from "@/components/qty-control";
import { WishButton } from "@/components/wish-button";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type Search = { renk?: ColorId };

export const Route = createFileRoute("/urun/$sku")({
  validateSearch: (raw: Record<string, unknown>): Search => ({
    renk: COLORS.some((c) => c.id === raw.renk) ? (raw.renk as ColorId) : undefined,
  }),
  beforeLoad: ({ params, search }) => {
    const p = getProduct(params.sku);
    if (!p) return;
    const slug = productSlug(p);
    if (params.sku !== slug) {
      throw redirect({
        to: "/urun/$sku",
        params: { sku: slug },
        search,
      });
    }
  },
  head: ({ params }) => {
    const p = getProduct(params.sku);
    if (!p) return pageHead({ title: "Ürün", path: `/urun/${params.sku}` });
    return pageHead({
      title: p.name,
      description: `${p.tagline} ${p.sku}. 8 deri renk, örnek fotoğraf.`,
      path: `/urun/${productSlug(p)}`,
    });
  },
  component: ProductPage,
});

function ProductPage() {
  const { sku } = Route.useParams();
  const { renk } = Route.useSearch();
  const navigate = Route.useNavigate();
  const product = getProduct(sku);
  if (!product) throw notFound();

  const [color, setColor] = useState<ColorId>(renk ?? "espresso");
  const [qty, setQty] = useState(1);
  const [zoom, setZoom] = useState(false);
  const add = useCart((s) => s.add);
  const addMany = useCart((s) => s.addMany);
  const pushRecent = usePrefs((s) => s.pushRecent);
  const recent = usePrefs((s) => s.recent);
  const colorMeta = getColor(color);
  const related = relatedProducts(product.sku);
  const series = getSeries(product.series);
  const cat = CATEGORIES.find((c) => c.id === product.category);
  const { prev: prevP, next: nextP } = neighborsInCategory(product.sku);
  const recentItems = recent
    .filter((s) => s !== product.sku)
    .map(getProduct)
    .filter((p): p is Product => p != null)
    .slice(0, 4);
  const weight = specGrams(product);
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    sku: product.sku,
    image: product.image,
    description: product.description,
    brand: { "@type": "Brand", name: "Sweb" },
    offers: {
      "@type": "Offer",
      price: product.price,
      priceCurrency: "TRY",
      availability: "https://schema.org/InStock",
    },
  };

  useEffect(() => {
    pushRecent(product.sku);
  }, [product.sku, pushRecent]);

  useEffect(() => {
    if (renk) setColor(renk);
  }, [renk]);

  function chooseColor(id: ColorId) {
    setColor(id);
    void navigate({
      search: { renk: id },
      replace: true,
    });
  }

  function addToCart() {
    if (!product) return;
    add(product.sku, color, qty);
  }

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-10 pb-[calc(7rem+var(--cookie-h,0px))] lg:pb-10">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <p className="font-mono text-[11px] text-fg-muted">
        <Link to="/koleksiyon" className="hover:text-fg">
          Ürünler
        </Link>
        {cat ? (
          <>
            <span className="px-2">/</span>
            <Link to="/kategori/$id" params={{ id: cat.id }} className="hover:text-fg">
              {cat.name}
            </Link>
          </>
        ) : null}
        {series ? (
          <>
            <span className="px-2">/</span>
            <Link
              to="/koleksiyon"
              search={{ kategori: "ofis", seri: series.id }}
              className="hover:text-fg"
            >
              {series.name}
            </Link>
          </>
        ) : null}
        <span className="px-2">/</span>
        <span>{product.name}</span>
      </p>

      <div className="mt-6 grid gap-10 lg:grid-cols-2">
        <div>
          <button
            type="button"
            className="w-full border border-dashed border-border text-left"
            style={{ backgroundColor: PASTEL[color] }}
            onClick={() => setZoom(true)}
            aria-label="Görseli büyüt"
          >
            <img
              src={product.image}
              alt={`${product.name} — örnek fotoğraf, ${colorMeta?.name ?? "deri"} zemin`}
              className="aspect-square w-full object-contain p-4"
            />
          </button>
          <p className="mt-2 font-mono text-[11px] text-fg-muted">
            8 renk, örnek fotoğraf. Seçilen renk zemini boyar, deriyi değil.
          </p>
        </div>
        <div className="flex flex-col gap-6">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="font-mono text-[11px] tracking-wide text-fg-muted">
                {product.sku}
              </p>
              <h1 className="mt-2 font-display text-4xl leading-none sm:text-5xl">{product.name}</h1>
              <p className="mt-3 text-base text-fg-muted">{product.tagline}</p>
            </div>
            <WishButton sku={product.sku} />
          </div>
          <div>
            <p className="font-mono text-2xl">{formatPrice(product.price)}</p>
            <p className="mt-1 font-mono text-[11px] text-fg-muted">KDV dahil · 8 deri renk</p>
          </div>

          <div>
            <div className="mb-3 flex items-center justify-between">
              <p className="text-sm">Renk</p>
              <p className="font-mono text-sm text-fg-muted">{colorMeta?.name}</p>
            </div>
            <ColorSwatches value={color} onChange={chooseColor} />
          </div>

          <div className="hidden flex-wrap items-center gap-3 lg:flex">
            <QtyControl value={qty} onChange={setQty} />
            <Button size="lg" className="min-w-40 flex-1" onClick={addToCart}>
              Sepete ekle
            </Button>
          </div>

          {series ? (
            <div className="border border-dashed border-border bg-bg-elevated p-4">
              <p className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">
                {series.name} kiti
              </p>
              <p className="mt-1 text-sm text-fg-muted">{series.blurb}</p>
              <Button
                variant="outline"
                className="mt-3"
                onClick={() => {
                  const skus = productsBySeries(series.id).map((p) => p.sku);
                  addMany(skus, color);
                  toast.success(`${skus.length} parça sepete eklendi`);
                }}
              >
                Seriyi sepete ekle
              </Button>
            </div>
          ) : null}

          <p className="max-w-prose text-sm leading-relaxed text-fg-muted">{product.description}</p>

          <p className="text-sm text-fg-muted">
            50 adet ve üzeri siparişte fiyat ve teslim planı ayrı çıkarılır.{" "}
            <Link to="/teklif" className="text-taba hover:underline">
              Bu ürün için teklif iste
            </Link>
            .
          </p>

          <ul className="grid gap-2 text-sm">
            {product.features.map((f) => (
              <li key={f} className="flex gap-2 text-fg">
                <span className="mt-2 size-1.5 shrink-0 bg-taba" />
                {f}
              </li>
            ))}
          </ul>

          <div className="border border-dashed border-border bg-bg-elevated p-4">
            <table className="w-full text-sm">
              <tbody>
                {product.specs.map((s) => (
                  <tr key={s.label} className="border-b border-dashed border-border last:border-0">
                    <td className="py-2 text-fg-muted">{s.label}</td>
                    <td className="py-2 text-right font-mono text-[13px]">
                      {s.label === "Ağırlık" ? weight : s.value}
                    </td>
                  </tr>
                ))}
                <tr className="border-b border-dashed border-border last:border-0">
                  <td className="py-2 text-fg-muted">Teslim</td>
                  <td className="py-2 text-right font-mono text-[13px]">3–5 iş günü</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="grid gap-3 border-t border-dashed border-border pt-6 text-sm">
            <p className="flex items-start gap-3">
              <Truck className="mt-0.5 size-4 shrink-0 text-fg-muted" />
              <span>
                3–5 iş günü. {formatPrice(FREE_SHIPPING_FROM)} üzeri kargo yok.
              </span>
            </p>
            <p className="flex items-start gap-3">
              <RotateCcw className="mt-0.5 size-4 shrink-0 text-fg-muted" />
              <span>14 gün, kullanılmamış iade.</span>
            </p>
            <p className="flex items-start gap-3">
              <Droplets className="mt-0.5 size-4 shrink-0 text-fg-muted" />
              <span>Nemli bez. Yağ ve çözücü yok.</span>
            </p>
          </div>
        </div>
      </div>

      <nav className="mt-12 flex items-center justify-between gap-4 border-t border-dashed border-border pt-6 text-sm">
        {prevP ? (
          <Link
            to="/urun/$sku"
            params={{ sku: productSlug(prevP) }}
            className="text-fg-muted hover:text-taba"
          >
            ← {prevP.name}
          </Link>
        ) : (
          <span />
        )}
        {nextP ? (
          <Link
            to="/urun/$sku"
            params={{ sku: productSlug(nextP) }}
            className="text-right text-fg-muted hover:text-taba"
          >
            {nextP.name} →
          </Link>
        ) : (
          <span />
        )}
      </nav>

      <section className="mt-20">
        <h2 className="font-display text-3xl">{series ? "Bu seride" : "Yanına"}</h2>
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {related.map((p) => (
            <ProductCard key={p.sku} product={p} />
          ))}
        </div>
      </section>

      {recentItems.length > 0 ? (
        <section className="mt-16">
          <h2 className="font-display text-3xl">Son baktıklarınız</h2>
          <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {recentItems.map((p) => (
              <ProductCard key={p.sku} product={p} />
            ))}
          </div>
        </section>
      ) : null}

      <div
        className="fixed inset-x-0 z-40 border-t border-dashed border-border bg-bg/95 p-3 lg:hidden"
        style={{ bottom: "var(--cookie-h, 0px)" }}
      >
        <div className="mx-auto flex max-w-[1400px] items-center gap-3">
          <QtyControl value={qty} onChange={setQty} />
          <Button className="flex-1" size="lg" onClick={addToCart}>
            Sepete ekle · {formatPrice(product.price * qty)}
          </Button>
        </div>
      </div>

      {zoom ? <ZoomLightbox src={product.image} alt={product.name} onClose={() => setZoom(false)} /> : null}
    </div>
  );
}

function ZoomLightbox({
  src,
  alt,
  onClose,
}: {
  src: string;
  alt: string;
  onClose: () => void;
}) {
  const [scale, setScale] = useState(1);
  const [origin, setOrigin] = useState("50% 50%");

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-bg-deep/80 p-4">
      <button
        type="button"
        className="absolute inset-0"
        aria-label="Kapat"
        onClick={onClose}
      />
      <img
        src={src}
        alt={alt}
        className="relative z-10 max-h-full max-w-full cursor-zoom-in object-contain transition-transform duration-200"
        style={{
          transform: `scale(${scale})`,
          transformOrigin: origin,
          cursor: scale > 1 ? "zoom-out" : "zoom-in",
        }}
        onClick={(e) => {
          e.stopPropagation();
          const rect = e.currentTarget.getBoundingClientRect();
          const x = ((e.clientX - rect.left) / rect.width) * 100;
          const y = ((e.clientY - rect.top) / rect.height) * 100;
          setOrigin(`${x}% ${y}%`);
          setScale((s) => (s === 1 ? 2.4 : 1));
        }}
      />
    </div>
  );
}
