import { createFileRoute, Link, notFound, redirect } from "@tanstack/react-router";
import {
  CATEGORIES,
  PRODUCTS,
  resolveCategory,
} from "@/lib/products";
import { pageHead } from "@/lib/seo";
import { ProductCard } from "@/components/product-card";
import { SeriesCards } from "@/components/series-cards";

export const Route = createFileRoute("/kategori/$id")({
  beforeLoad: ({ params }) => {
    const resolved = resolveCategory(params.id);
    if (resolved && resolved !== params.id) {
      throw redirect({ to: "/kategori/$id", params: { id: resolved } });
    }
  },
  head: ({ params }) => {
    const catId = resolveCategory(params.id);
    const cat = CATEGORIES.find((c) => c.id === catId);
    return pageHead({
      title: cat?.name ?? "Kategori",
      description: cat?.blurb,
      path: `/kategori/${catId ?? params.id}`,
    });
  },
  component: CategoryPage,
});

function CategoryPage() {
  const { id } = Route.useParams();
  const catId = resolveCategory(id);
  const cat = CATEGORIES.find((c) => c.id === catId);
  if (!cat) throw notFound();

  const items = PRODUCTS.filter((p) => p.category === cat.id);

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-10">
      <p className="font-mono text-[11px] text-fg-muted">
        <Link to="/kategori" className="hover:text-fg">
          Ürünler
        </Link>
        <span className="px-2">/</span>
        <span>{cat.name}</span>
      </p>
      <h1 className="mt-3 font-display text-4xl sm:text-5xl">{cat.name}</h1>
      <p className="mt-3 max-w-xl text-sm text-fg-muted">
        {cat.blurb} {items.length} parça, sekiz deri renk.
      </p>

      {cat.id === "ofis" ? (
        <div className="mt-10">
          <p className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">Masa setleri</p>
          <div className="mt-4">
            <SeriesCards />
          </div>
        </div>
      ) : null}

      <p className="mt-10 font-mono text-sm text-fg-muted">{items.length} parça</p>
      <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {items.map((p) => (
          <ProductCard key={p.sku} product={p} />
        ))}
      </div>

      <div className="mt-16">
        <p className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">Diğer odalar</p>
        <ul className="mt-4 flex flex-wrap gap-x-6 gap-y-2 text-sm">
          {CATEGORIES.filter((c) => c.id !== cat.id).map((c) => (
            <li key={c.id}>
              <Link
                to="/kategori/$id"
                params={{ id: c.id }}
                className="text-fg-muted hover:text-taba"
              >
                {c.name}
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
