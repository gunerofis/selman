import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Heart, Menu, Search, ShoppingBag, X } from "lucide-react";
import { Toaster } from "sonner";
import { cartCount, useCart } from "@/lib/cart";
import { usePrefs } from "@/lib/prefs";
import { CATEGORIES, PRODUCT_COUNT } from "@/lib/products";
import { BRAND } from "@/lib/brand";
import { useHydrated } from "@/lib/use-hydrated";
import { CartDrawer } from "@/components/cart-drawer";
import { SearchPanel } from "@/components/search-panel";
import { CookieBar, openCookiePrefs } from "@/components/cookie-bar";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/koleksiyon" as const, label: "Ürünler" },
  { to: "/setler" as const, label: "Ofis setleri" },
  { to: "/tasarla" as const, label: "Tasarlayın" },
  { to: "/atolye" as const, label: "Atölye" },
];

export function SiteShell({ children }: { children: React.ReactNode }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const ready = useHydrated();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const lines = useCart((s) => s.lines);
  const openDrawer = useCart((s) => s.openDrawer);
  const wishCount = usePrefs((s) => s.wishlist.length);
  const count = ready ? cartCount(lines) : 0;
  const wishes = ready ? wishCount : 0;

  useEffect(() => {
    setMenuOpen(false);
    setSearchOpen(false);
  }, [pathname]);

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <a
        href="#icerik"
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:bg-fg focus:px-4 focus:py-2 focus:text-bg-elevated"
      >
        İçeriğe geç
      </a>
      <Toaster
        position="top-center"
        toastOptions={{
          className: "!bg-bg-deep !text-fg-on-deep !border-none !rounded-none !font-sans",
        }}
      />
      <div className="border-b border-dashed border-border bg-bg-wash px-4 py-2 text-center font-mono text-xs tracking-wide text-fg">
        5.000 ₺ üzeri kargo yok · 3–5 iş günü · 14 gün iade
      </div>
      <header className="sticky top-0 z-40 border-b border-dashed border-border bg-bg/95">
        <div className="mx-auto flex h-16 max-w-[1400px] items-center justify-between gap-3 px-4">
          <button
            type="button"
            className="flex size-11 items-center justify-center lg:hidden"
            aria-label={menuOpen ? "Menüyü kapat" : "Menüyü aç"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((v) => !v)}
          >
            {menuOpen ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
          <Link
            to="/"
            className="font-display text-2xl tracking-[0.08em] text-fg"
            aria-label={`${BRAND.name} ana sayfa`}
          >
            {BRAND.name}
          </Link>
          <nav className="hidden items-center gap-6 lg:flex">
            {NAV.map((item) => {
              const on =
                pathname === item.to || pathname.startsWith(`${item.to}/`);
              return (
                <Link
                  key={item.label}
                  to={item.to}
                  aria-current={on ? "page" : undefined}
                  className={cn(
                    "text-sm transition-colors duration-200 hover:text-fg",
                    on ? "text-fg" : "text-fg-muted",
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <div className="flex items-center">
            <button
              type="button"
              className="flex size-11 items-center justify-center"
              aria-label="Ara"
              onClick={() => setSearchOpen(true)}
            >
              <Search className="size-5" />
            </button>
            <Link
              to="/favoriler"
              className="relative flex size-11 items-center justify-center"
              aria-label="Favoriler"
            >
              <Heart className="size-5" />
              {wishes > 0 ? (
                <span className="absolute top-1.5 right-1.5 flex h-4 min-w-4 items-center justify-center bg-accent px-1 font-mono text-[10px] leading-none text-accent-fg">
                  {wishes}
                </span>
              ) : null}
            </Link>
            <button
              type="button"
              className="relative flex size-11 items-center justify-center"
              aria-label="Sepet"
              onClick={openDrawer}
            >
              <ShoppingBag className="size-5" />
              {count > 0 ? (
                <span className="absolute top-1.5 right-1.5 flex h-4 min-w-4 items-center justify-center bg-accent px-1 font-mono text-[10px] leading-none text-accent-fg">
                  {count}
                </span>
              ) : null}
            </button>
          </div>
        </div>
        {menuOpen ? (
          <div className="border-t border-dashed border-border bg-bg px-4 py-4 lg:hidden">
            <nav className="flex flex-col">
              {NAV.map((item) => {
                const on =
                  pathname === item.to || pathname.startsWith(`${item.to}/`);
                return (
                  <Link
                    key={item.label}
                    to={item.to}
                    aria-current={on ? "page" : undefined}
                    className={cn(
                      "flex h-12 items-center text-base",
                      on ? "text-fg" : "text-fg-muted",
                    )}
                  >
                    {item.label}
                  </Link>
                );
              })}
              <Link to="/favoriler" className="flex h-12 items-center text-base text-fg">
                Favoriler
              </Link>
              <Link to="/iletisim" className="flex h-12 items-center text-base text-fg-muted">
                İletişim
              </Link>
            </nav>
          </div>
        ) : null}
      </header>
      <main id="icerik" className="flex-1">
        {children}
      </main>
      <footer className="mt-auto border-t border-dashed border-border bg-bg-deep text-fg-on-deep">
        <div className="mx-auto grid max-w-[1400px] gap-10 px-4 py-14 sm:grid-cols-2 lg:grid-cols-4">
          <div className="sm:col-span-2">
            <p className="font-display text-3xl tracking-[0.08em]">{BRAND.name}</p>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-fg-on-deep/70">
              {BRAND.tagline} {PRODUCT_COUNT} parça, sekiz renk. İstanbul atölyesi.
            </p>
          </div>
          <div>
            <p className="font-mono text-xs tracking-widest uppercase text-fg-on-deep/50">
              Oda
            </p>
            <ul className="mt-3 space-y-2 text-sm">
              {CATEGORIES.map((c) => (
                <li key={c.id}>
                  <Link
                    to="/kategori/$id"
                    params={{ id: c.id }}
                    className="text-fg-on-deep/80 hover:text-fg-on-deep"
                  >
                    {c.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="font-mono text-xs tracking-widest uppercase text-fg-on-deep/50">
              Atölye
            </p>
            <ul className="mt-3 space-y-2 text-sm">
              <li>
                <Link to="/tasarla" className="text-fg-on-deep/80 hover:text-fg-on-deep">
                  Tasarlayın
                </Link>
              </li>
              <li>
                <Link to="/koleksiyon" className="text-fg-on-deep/80 hover:text-fg-on-deep">
                  Ürünler
                </Link>
              </li>
              <li>
                <Link to="/setler" className="text-fg-on-deep/80 hover:text-fg-on-deep">
                  Ofis setleri
                </Link>
              </li>
              <li>
                <Link to="/atolye" className="text-fg-on-deep/80 hover:text-fg-on-deep">
                  Atölye
                </Link>
              </li>
              <li>
                <Link to="/teklif" className="text-fg-on-deep/80 hover:text-fg-on-deep">
                  Kurumsal teklif
                </Link>
              </li>
              <li>
                <Link to="/iletisim" className="text-fg-on-deep/80 hover:text-fg-on-deep">
                  İletişim
                </Link>
              </li>
              <li>
                <Link to="/teslimat" className="text-fg-on-deep/80 hover:text-fg-on-deep">
                  Teslimat
                </Link>
              </li>
              <li>
                <Link to="/iade" className="text-fg-on-deep/80 hover:text-fg-on-deep">
                  İade
                </Link>
              </li>
              <li>
                <Link to="/gizlilik" className="text-fg-on-deep/80 hover:text-fg-on-deep">
                  Gizlilik politikası
                </Link>
              </li>
              <li>
                <Link to="/cerez" className="text-fg-on-deep/80 hover:text-fg-on-deep">
                  Çerez politikası
                </Link>
              </li>
              <li>
                <Link to="/kvkk" className="text-fg-on-deep/80 hover:text-fg-on-deep">
                  KVKK aydınlatma
                </Link>
              </li>
              <li>
                <Link to="/mesafeli" className="text-fg-on-deep/80 hover:text-fg-on-deep">
                  Mesafeli satış
                </Link>
              </li>
              <li>
                <button
                  type="button"
                  onClick={openCookiePrefs}
                  className="text-fg-on-deep/80 hover:text-fg-on-deep"
                >
                  Çerez tercihleri
                </button>
              </li>
              <li>
                <a href={`mailto:${BRAND.email}`} className="text-fg-on-deep/80 hover:text-fg-on-deep">
                  {BRAND.email}
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-fg-on-deep/10 px-4 py-5 text-center font-mono text-xs text-fg-on-deep/50">
          © {new Date().getFullYear()} {BRAND.name} · İstanbul
        </div>
      </footer>
      <CartDrawer />
      <SearchPanel open={searchOpen} onClose={() => setSearchOpen(false)} />
      <CookieBar />
    </div>
  );
}
