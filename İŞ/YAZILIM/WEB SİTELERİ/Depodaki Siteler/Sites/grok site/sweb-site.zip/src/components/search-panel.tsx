import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Search, X } from "lucide-react";
import { WALL_SKUS, getProduct, productSlug, searchProducts } from "@/lib/products";
import { formatPrice, cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";

const JOBS = ["şarj", "baharat", "gözlük", "dizüstü", "saat", "anahtar"];

export function SearchPanel({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const [q, setQ] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) {
      setQ("");
      const t = window.setTimeout(() => inputRef.current?.focus(), 50);
      return () => window.clearTimeout(t);
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
        return;
      }
      if (e.key !== "Tab") return;
      const root = panelRef.current;
      if (!root) return;
      const focusable = [
        ...root.querySelectorAll<HTMLElement>(
          'a[href],button:not([disabled]),input:not([disabled])',
        ),
      ].filter((el) => el.tabIndex !== -1);
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const results = useMemo(() => {
    const needle = q.trim();
    if (needle.length < 1) {
      return WALL_SKUS.map(getProduct)
        .filter((p): p is NonNullable<typeof p> => p != null)
        .slice(0, 6);
    }
    return searchProducts(needle, 8);
  }, [q]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50">
      <button
        type="button"
        aria-label="Kapat"
        className="absolute inset-0 bg-bg-deep/40"
        onClick={onClose}
      />
      <div
        ref={panelRef}
        role="dialog"
        aria-label="Ara"
        className="absolute inset-x-0 top-0 border-b border-dashed border-border bg-bg px-4 pt-4 pb-6"
      >
        <div className="mx-auto max-w-2xl">
          <div className="flex items-center gap-2 border-b border-dashed border-border pb-2">
            <Search className="size-4 shrink-0 text-fg-muted" />
            <Input
              ref={inputRef}
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="şarj, baharat, gözlük, dizüstü"
              aria-label="Ara"
              className="border-0 bg-transparent focus-visible:ring-0"
            />
            <button
              type="button"
              className="flex size-11 items-center justify-center"
              aria-label="Kapat"
              onClick={onClose}
            >
              <X className="size-5" />
            </button>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            {JOBS.map((job) => (
              <button
                key={job}
                type="button"
                onClick={() => setQ(job)}
                className={cn(
                  "h-11 border px-3 text-sm",
                  q.trim().toLocaleLowerCase("tr") === job
                    ? "border-fg bg-fg text-bg-elevated"
                    : "border-border-strong text-fg-muted hover:border-fg hover:text-fg",
                )}
              >
                {job}
              </button>
            ))}
          </div>
          <ul className="mt-2 divide-y divide-dashed divide-border">
            {results.map((p) => (
              <li key={p.sku}>
                <Link
                  to="/urun/$sku"
                  params={{ sku: productSlug(p) }}
                  onClick={onClose}
                  className="flex items-center gap-3 py-3 hover:bg-bg-elevated"
                >
                  <img
                    src={p.image}
                    alt=""
                    className="size-14 bg-bg-wash object-contain"
                  />
                  <span className="min-w-0 flex-1">
                    <span className="block font-display text-lg leading-tight">{p.name}</span>
                    <span className="font-mono text-xs text-fg-subtle">{p.sku}</span>
                  </span>
                  <span className="font-mono text-sm text-fg-muted tabular-nums">
                    {formatPrice(p.price)}
                  </span>
                </Link>
              </li>
            ))}
            {results.length === 0 ? (
              <li className="py-6 text-center text-sm text-fg-muted">Eşleşen parça yok.</li>
            ) : null}
          </ul>
          <Link
            to="/koleksiyon"
            search={q ? { q } : undefined}
            onClick={onClose}
            className="mt-3 block text-center text-sm text-fg-muted hover:text-fg"
          >
            Tüm ürünlerde ara
          </Link>
        </div>
      </div>
    </div>
  );
}
