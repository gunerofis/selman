export function LegalPage({
  kicker,
  title,
  children,
}: {
  kicker: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <article className="mx-auto max-w-2xl px-4 py-14">
      <p className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">{kicker}</p>
      <h1 className="mt-3 font-display text-4xl">{title}</h1>
      <div className="mt-8 space-y-4 text-sm leading-relaxed text-fg-muted">{children}</div>
    </article>
  );
}
