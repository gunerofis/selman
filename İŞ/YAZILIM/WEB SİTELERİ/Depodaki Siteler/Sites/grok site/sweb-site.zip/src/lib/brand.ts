export const BRAND = {
  name: "Sweb",
  tagline: "Ev ve çalışma alanı için düzen ürünleri.",
  email: "selam@sweb.co",
  atelier: "Bomonti, Şişli · İstanbul",
  hours: "09.00–18.00",
  reply: "1 iş günü",
} as const;
