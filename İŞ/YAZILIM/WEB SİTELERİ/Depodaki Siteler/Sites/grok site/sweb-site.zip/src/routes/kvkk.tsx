import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/legal-page";
import { BRAND } from "@/lib/brand";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/kvkk")({
  component: Page,
  head: () =>
    pageHead({
      title: "KVKK aydınlatma",
      description: "Önizlemede veri tarayıcıda kalır.",
      path: "/kvkk",
    }),
});

function Page() {
  return (
    <LegalPage kicker="Hukuki" title="KVKK aydınlatma metni">
      <p>
        Bu aydınlatma önizleme içindir. Sipariş ve form alanları tarayıcıda
        kalır; sunucuya yazılmaz. Yasal tüzel kişi bu demoda tanımlanmaz.
        Sorular: {BRAND.email}.
      </p>
      <p>
        6698 sayılı Kanun kapsamında toplanabilecek veriler: kimlik, iletişim
        ve teslimat bilgisi — canlı satış açıldığında.
      </p>
      <p>
        Amaç: siparişi yerine getirmek, fatura kesmek, talebe cevap vermek.
        Dayanak: sözleşmenin kurulması ve meşru menfaat.
      </p>
      <p>
        Veriler yasal saklama süreleri boyunca tutulur, sonra silinir veya
        anonimleştirilir. Üçüncü kişilere kargo ve muhasebe dışında aktarılmaz.
      </p>
      <p>
        Erişim, düzeltme, silme ve itiraz talepleri {BRAND.email} adresine yazılır.
      </p>
    </LegalPage>
  );
}
