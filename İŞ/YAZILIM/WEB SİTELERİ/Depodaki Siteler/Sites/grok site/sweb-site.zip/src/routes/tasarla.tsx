import { type FormEvent, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import {
  COLORS,
  getProduct,
  type ColorId,
} from "@/lib/products";
import {
  FEATURES,
  FORMS,
  MATERIALS,
  quoteDesign,
  type DesignQuote,
} from "@/lib/design";
import { pageHead } from "@/lib/seo";
import { formatPrice } from "@/lib/utils";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ProductCard } from "@/components/product-card";
import { DemoNotice } from "@/components/demo-notice";

export const Route = createFileRoute("/tasarla")({
  component: DesignPage,
  head: () =>
    pageHead({
      title: "Tasarlayın",
      description: "Ölçüye göre düzen ürünü. İlk fiyat tahmini.",
      path: "/tasarla",
    }),
});

function DesignPage() {
  const [brief, setBrief] = useState("");
  const [form, setForm] = useState("");
  const [materials, setMaterials] = useState<string[]>(["Deri kaplama"]);
  const [features, setFeatures] = useState<string[]>([]);
  const [color, setColor] = useState<ColorId | "">("");
  const [widthMm, setWidthMm] = useState("");
  const [depthMm, setDepthMm] = useState("");
  const [heightMm, setHeightMm] = useState("");
  const [qty, setQty] = useState("1");
  const [email, setEmail] = useState("");
  const [trap, setTrap] = useState("");
  const [busy, setBusy] = useState(false);
  const [quote, setQuote] = useState<DesignQuote | null>(null);

  const waiting = useMemo(
    () =>
      ["7043", "7054", "7012", "7036"]
        .map(getProduct)
        .filter((p): p is NonNullable<typeof p> => p != null),
    [],
  );

  function toggle(list: string[], value: string, set: (v: string[]) => void) {
    set(list.includes(value) ? list.filter((x) => x !== value) : [...list, value]);
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setQuote(null);
    try {
      const result = await quoteDesign({
        data: {
          brief,
          form,
          materials,
          features,
          color,
          widthMm: widthMm ? Number(widthMm) : null,
          depthMm: depthMm ? Number(depthMm) : null,
          heightMm: heightMm ? Number(heightMm) : null,
          qty: Math.max(1, Number(qty) || 1),
          email,
          trap,
        },
      });
      if (!result.ok) {
        toast.error(result.error);
        return;
      }
      setQuote(result.quote);
      toast.success("Tahmini ölçü ve fiyat çıktı.");
    } catch {
      toast.error("Bağlantı kesildi. Yeniden deneyin.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-[1100px] px-4 py-10">
      <p className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">Atölye</p>
      <h1 className="mt-2 font-display text-4xl sm:text-5xl">Tasarımınızı gönderin</h1>
      <p className="mt-3 max-w-xl text-sm text-fg-muted">
        Aklınızdaki düzen ürününü kendi cümlelerinizle yazın. Çıkan ölçü ve fiyat
        ilk tahmindir; onay ve numuneden sonra netleşir.
      </p>

      <div className="mt-10 grid gap-10 lg:grid-cols-[1.1fr_0.9fr]">
        <form onSubmit={onSubmit} className="flex flex-col gap-6">
          <DemoNotice>
            Fiyat tahmini tarayıcıda çıkar. Form atölyeye gönderilmez.
          </DemoNotice>
          <label className="grid gap-1.5 text-sm">
            <span className="font-mono text-[11px] text-fg-muted">ne istiyorsunuz</span>
            <textarea
              required
              minLength={8}
              rows={4}
              value={brief}
              onChange={(e) => setBrief(e.target.value)}
              placeholder="Çekmeceye oturan, kalem ve kart için üç gözlü tepsi."
              className="border border-border-strong bg-bg-elevated px-3 py-2 text-sm text-fg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </label>

          <fieldset>
            <legend className="font-mono text-[11px] text-fg-muted">form</legend>
            <div className="mt-2 grid gap-2 sm:grid-cols-2">
              {FORMS.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setForm(form === f.label ? "" : f.label)}
                  className={cn(
                    "border px-3 py-3 text-left text-sm",
                    form === f.label
                      ? "border-fg bg-fg text-bg-elevated"
                      : "border-border-strong text-fg hover:border-fg",
                  )}
                >
                  <span className="block font-medium">{f.label}</span>
                  <span className={cn("mt-1 block text-[12px]", form === f.label ? "text-bg-elevated/70" : "text-fg-muted")}>
                    {f.hint}
                  </span>
                </button>
              ))}
            </div>
          </fieldset>

          <fieldset>
            <legend className="font-mono text-[11px] text-fg-muted">malzeme</legend>
            <div className="mt-2 flex flex-wrap gap-2">
              {MATERIALS.map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => toggle(materials, m, setMaterials)}
                  className={cn(
                    "h-9 border px-3 text-sm",
                    materials.includes(m)
                      ? "border-fg bg-fg text-bg-elevated"
                      : "border-border-strong text-fg-muted hover:border-fg",
                  )}
                >
                  {m}
                </button>
              ))}
            </div>
          </fieldset>

          <fieldset>
            <legend className="font-mono text-[11px] text-fg-muted">özellik</legend>
            <div className="mt-2 flex flex-wrap gap-2">
              {FEATURES.map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => toggle(features, m, setFeatures)}
                  className={cn(
                    "h-9 border px-3 text-sm",
                    features.includes(m)
                      ? "border-fg bg-fg text-bg-elevated"
                      : "border-border-strong text-fg-muted hover:border-fg",
                  )}
                >
                  {m}
                </button>
              ))}
            </div>
          </fieldset>

          <fieldset>
            <legend className="font-mono text-[11px] text-fg-muted">renk</legend>
            <p className="mt-1 text-xs text-fg-muted">Seçmezseniz forma uygun rengi biz öneririz.</p>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              {COLORS.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  title={c.name}
                  aria-label={c.name}
                  onClick={() => setColor(color === c.id ? "" : c.id)}
                  className={cn(
                    "size-[22px] border border-border-strong",
                    color === c.id && "outline-2 outline-offset-2 outline-taba",
                  )}
                  style={{ backgroundColor: c.swatch }}
                />
              ))}
              <span className="font-mono text-[11px] text-fg-muted">
                {color ? COLORS.find((c) => c.id === color)?.name : "Atölye önerir"}
              </span>
            </div>
          </fieldset>

          <div>
            <p className="font-mono text-[11px] text-fg-muted">ölçü — mm, biliyorsanız (80–900)</p>
            <div className="mt-2 grid grid-cols-3 gap-2">
              <Input inputMode="numeric" placeholder="en" value={widthMm} onChange={(e) => setWidthMm(e.target.value)} />
              <Input inputMode="numeric" placeholder="boy" value={depthMm} onChange={(e) => setDepthMm(e.target.value)} />
              <Input inputMode="numeric" placeholder="yükseklik" value={heightMm} onChange={(e) => setHeightMm(e.target.value)} />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <label className="grid gap-1.5 text-sm">
              <span className="font-mono text-[11px] text-fg-muted">adet</span>
              <Input
                type="number"
                min={1}
                required
                value={qty}
                onChange={(e) => setQty(e.target.value)}
              />
            </label>
            <label className="grid gap-1.5 text-sm">
              <span className="font-mono text-[11px] text-fg-muted">e-posta</span>
              <Input
                type="email"
                required
                placeholder="ad@firma.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </label>
          </div>

          <label className="flex items-start gap-2 text-sm">
            <input type="checkbox" name="kvkk" required className="mt-1 size-4 shrink-0" />
            <span>
              <Link to="/kvkk" className="underline-offset-2 hover:underline">
                KVKK aydınlatmasını
              </Link>{" "}
              okudum. Form atölyeye gönderilmez.
            </span>
          </label>

          <div className="hidden" aria-hidden>
            <label>
              Bu alanı boş bırakın
              <input value={trap} onChange={(e) => setTrap(e.target.value)} tabIndex={-1} autoComplete="off" />
            </label>
          </div>

          <Button type="submit" size="lg" disabled={busy}>
            {busy ? "Ölçülüyor…" : "Tasarımı gönder"}
          </Button>
        </form>

        <aside className="flex flex-col gap-6">
          {busy ? (
            <div className="border border-dashed border-border bg-bg-elevated p-5">
              <p className="font-mono text-[11px] text-fg-muted">Beklerken</p>
              <p className="mt-2 font-display text-2xl">Yakın ürettiklerimiz</p>
              <div className="mt-4 grid gap-4">
                {waiting.map((p) => (
                  <ProductCard key={p.sku} product={p} />
                ))}
              </div>
            </div>
          ) : quote ? (
            <div className="border border-dashed border-border bg-bg-elevated p-5">
              <p className="font-mono text-[11px] text-fg-muted">taslak</p>
              <h2 className="mt-1 font-display text-3xl">{quote.name}</h2>
              <p className="mt-3 text-sm text-fg-muted">{quote.summary}</p>
              <table className="mt-5 w-full text-sm">
                <tbody>
                  {[
                    ["Form", quote.form],
                    ["Ölçü", `${quote.widthMm} × ${quote.depthMm} × ${quote.heightMm} mm`],
                    ["Renk", quote.color],
                    ["Malzeme", quote.materials.join(", ") || "—"],
                    ["Özellik", quote.features.join(", ") || "—"],
                    ["Adet", String(quote.qty)],
                    ["Birim", formatPrice(quote.unitPrice)],
                    ["Toplam", formatPrice(quote.total)],
                    ["Teslim", quote.lead],
                  ].map(([k, v]) => (
                    <tr key={k} className="border-b border-dashed border-border">
                      <td className="py-2 text-fg-muted">{k}</td>
                      <td className="py-2 text-right font-mono text-[13px]">{v}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="mt-4 text-sm text-fg-muted">{quote.notes}</p>
              <div className="mt-5 flex flex-wrap gap-2">
                <Link to="/teklif">
                  <Button>Teklif iste</Button>
                </Link>
                <Link to="/iletisim">
                  <Button variant="outline">Atölyeye yazın</Button>
                </Link>
              </div>
              {quote.similar.length > 0 ? (
                <div className="mt-8">
                  <p className="font-mono text-[11px] text-fg-muted">Yakın stok</p>
                  <div className="mt-3 grid gap-4">
                    {quote.similar.map(getProduct).map((p) =>
                      p ? <ProductCard key={p.sku} product={p} /> : null,
                    )}
                  </div>
                </div>
              ) : null}
            </div>
          ) : (
            <div className="border border-dashed border-border bg-bg-wash p-5">
              <p className="font-mono text-[11px] text-fg-muted">Nasıl işliyor</p>
              <ol className="mt-3 space-y-2 text-sm text-fg-muted">
                <li>1. Ne istediğinizi anlatın.</li>
                <li>2. İlk fiyat tahmini çıkar; onaydan sonra netleşir.</li>
                <li>3. Beklerken benzer ürettiklerimizi görürsünüz.</li>
                <li>4. Onaylarsanız numune 10–15 iş gününde çıkar.</li>
              </ol>
            </div>
          )}

          <div className="border border-dashed border-border p-5">
            <p className="font-mono text-[11px] text-fg-muted">Yapmadıklarımız</p>
            <ul className="mt-3 space-y-1.5 text-sm text-fg-muted">
              <li>Elektrikli veya elektronik parça</li>
              <li>Cam ve seramik gövde</li>
              <li>Dış mekân ve suya dayanıklı ürün</li>
              <li>Tek parçada 900 mm üstü ölçü</li>
              <li>Gıdayla doğrudan temas eden yüzey</li>
            </ul>
            <p className="mt-4 text-sm">
              Hazır ürün mü arıyorsunuz?{" "}
              <Link to="/koleksiyon" className="text-taba hover:underline">
                Koleksiyona bakın
              </Link>
              .
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}
