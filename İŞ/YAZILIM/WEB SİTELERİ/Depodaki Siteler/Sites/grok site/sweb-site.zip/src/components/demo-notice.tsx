export function DemoNotice({ children }: { children: React.ReactNode }) {
  return (
    <p className="border border-dashed border-border bg-bg-wash px-3 py-2 text-sm text-fg-muted">
      {children}
    </p>
  );
}
