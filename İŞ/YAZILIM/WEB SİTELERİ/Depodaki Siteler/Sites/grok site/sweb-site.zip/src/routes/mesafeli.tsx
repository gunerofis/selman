import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/legal-page";
import { BRAND } from "@/lib/brand";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/mesafeli")({
  component: Page,
  head: () =>
    pageHead({
      title: "Mesafeli satış",
      description: "Önizleme sözleşmesi. Tahsilat yok.",
      path: "/mesafeli",
    }),
});

function Page() {
  return (
    <LegalPage kicker="Hukuki" title="Mesafeli satış sözleşmesi">
      <p>
        Bu metin önizlemedir. Siteden verilen siparişlerde tahsilat yoktur;
        sipariş numarası tarayıcıda üretilir. Canlı satış açıldığında satıcı
        {BRAND.name} ile alıcı arasında sözleşme kurulur.
      </p>
      <p>
        Ödeme: kapıda nakit/kart veya havale. Havale seçilirse 2 iş günü içinde
        açıklamalı dekont beklenir.
      </p>
      <p>
        Cayma hakkı, teslimden itibaren 14 gündür. Kullanılmış, hasarlı veya
        kişiye özel ürünler cayma dışı kalır. Cayma bildirimi e-posta ile
        yapılır.
      </p>
      <p>
        Uyuşmazlıklarda Tüketici Hakem Heyetleri ve Tüketici Mahkemeleri
        yetkilidir.
      </p>
    </LegalPage>
  );
}
