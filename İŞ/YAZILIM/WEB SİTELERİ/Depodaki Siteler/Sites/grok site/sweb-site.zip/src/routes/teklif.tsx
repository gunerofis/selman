import { type FormEvent, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { pageHead } from "@/lib/seo";
import { DemoNotice } from "@/components/demo-notice";

export const Route = createFileRoute("/teklif")({
  component: Quote,
  head: () =>
    pageHead({
      title: "Kurumsal teklif",
      description: "50 adet ve üzeri. Bu önizlemede talep gönderilmez.",
      path: "/teklif",
    }),
});

function Quote() {
  const [sent, setSent] = useState(false);

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const adet = Number(new FormData(form).get("adet") || 0);
    if (adet < 50) {
      toast.error("Kurumsal teklif en az 50 adet.");
      return;
    }
    setSent(true);
    toast.success("Önizleme: talep tarayıcıda kaldı, gönderilmedi.");
    form.reset();
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-14">
      <p className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">Kurumsal</p>
      <h1 className="mt-3 font-display text-4xl sm:text-5xl">Kurumsal teklif</h1>
      <p className="mt-4 max-w-prose text-sm leading-relaxed text-fg-muted">
        Adet, ürün ve teslim tarihini yazın; iki iş günü içinde fiyat ve teslim
        planıyla dönüş yapılır.
      </p>
      <dl className="mt-8 grid grid-cols-2 gap-4 text-sm sm:grid-cols-4">
        {[
          ["En az adet", "50"],
          ["Dönüş", "2 iş günü"],
          ["Üretim", "10–20 iş günü"],
          ["Logo baskı", "Var"],
        ].map(([k, v]) => (
          <div key={k} className="border border-dashed border-border bg-bg-elevated px-3 py-3">
            <dt className="font-mono text-[11px] text-fg-muted">{k}</dt>
            <dd className="mt-1">{v}</dd>
          </div>
        ))}
      </dl>
      <form
        onSubmit={onSubmit}
        className="mt-10 flex flex-col gap-4 border border-dashed border-border bg-bg-elevated p-6"
      >
        <DemoNotice>Bu form tarayıcıda kalır, atölyeye gönderilmez.</DemoNotice>
        <label className="grid gap-1.5 text-sm">
          <span className="font-mono text-[11px] text-fg-muted">firma</span>
          <Input name="firma" required autoComplete="organization" />
        </label>
        <label className="grid gap-1.5 text-sm">
          <span className="font-mono text-[11px] text-fg-muted">yetkili</span>
          <Input name="yetkili" required autoComplete="name" />
        </label>
        <label className="grid gap-1.5 text-sm">
          <span className="font-mono text-[11px] text-fg-muted">e-posta</span>
          <Input name="email" type="email" required autoComplete="email" placeholder="ad@firma.com" />
        </label>
        <label className="grid gap-1.5 text-sm">
          <span className="font-mono text-[11px] text-fg-muted">telefon</span>
          <Input name="tel" type="tel" autoComplete="tel" placeholder="5xx xxx xx xx" />
        </label>
        <label className="grid gap-1.5 text-sm">
          <span className="font-mono text-[11px] text-fg-muted">adet</span>
          <Input name="adet" type="number" min={50} required defaultValue={50} />
        </label>
        <label className="grid gap-1.5 text-sm">
          <span className="font-mono text-[11px] text-fg-muted">not</span>
          <textarea
            name="not"
            required
            rows={5}
            placeholder="Stok kodu, renk, teslim tarihi"
            className="border border-border-strong bg-bg-elevated px-3 py-2 font-mono text-sm text-fg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
        </label>
        <label className="flex items-start gap-2 text-sm">
          <input type="checkbox" name="kvkk" required className="mt-1 size-4 shrink-0" />
          <span>
            <Link to="/kvkk" className="underline-offset-2 hover:underline">
              KVKK aydınlatmasını
            </Link>{" "}
            okudum.
          </span>
        </label>
        <div className="hidden" aria-hidden>
          <label>
            Bu alanı boş bırakın
            <input name="trap" tabIndex={-1} autoComplete="off" />
          </label>
        </div>
        <Button type="submit" size="lg">
          Teklif iste
        </Button>
        {sent ? (
          <p className="font-mono text-xs text-taba">Önizleme. Gönderilmedi.</p>
        ) : null}
      </form>
    </div>
  );
}
