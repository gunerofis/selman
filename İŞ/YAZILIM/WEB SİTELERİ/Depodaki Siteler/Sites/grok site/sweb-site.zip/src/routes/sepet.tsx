import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Trash2 } from "lucide-react";
import { cartCount, cartSubtotal, shippingFor, useCart } from "@/lib/cart";
import { FREE_SHIPPING_FROM, getColor, getProduct, productSlug } from "@/lib/products";
import { pageHead } from "@/lib/seo";
import { formatPrice } from "@/lib/utils";
import { ColorDot } from "@/components/color-swatch";
import { EmptyHint, QtyControl } from "@/components/qty-control";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/sepet")({
  component: CartPage,
  head: () =>
    pageHead({
      title: "Sepet",
      description: "Sepet tarayıcıda tutulur.",
      path: "/sepet",
    }),
});

function CartPage() {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  const lines = useCart((s) => s.lines);
  const setQty = useCart((s) => s.setQty);
  const remove = useCart((s) => s.remove);
  const subtotal = cartSubtotal(lines);
  const shipping = shippingFor(subtotal);
  const total = subtotal + shipping;
  const remaining = Math.max(0, FREE_SHIPPING_FROM - subtotal);

  if (!ready) {
    return <div className="mx-auto max-w-6xl px-4 py-20 text-sm text-fg-muted">Sepet yükleniyor…</div>;
  }

  if (lines.length === 0) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-16">
        <EmptyHint
          title="Sepet boş"
          body="Koleksiyondan bir parça seçin — sekiz deri renk sizi bekliyor."
          action={
            <Link to="/koleksiyon">
              <Button>Koleksiyona git</Button>
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div className="mx-auto grid max-w-6xl gap-10 px-4 py-10 lg:grid-cols-[1fr_320px]">
      <div>
        <h1 className="font-display text-4xl">Sepet</h1>
        <p className="mt-1 text-sm text-fg-muted">{cartCount(lines)} parça</p>
        <ul className="mt-8 divide-y divide-dashed divide-border border-y border-dashed border-border">
          {lines.map((line) => {
            const p = getProduct(line.sku);
            if (!p) return null;
            const color = getColor(line.color);
            return (
              <li key={`${line.sku}-${line.color}`} className="flex gap-4 py-5">
                <Link
                  to="/urun/$sku"
                  params={{ sku: productSlug(p) }}
                  className="size-24 shrink-0 overflow-hidden border border-dashed border-border bg-bg-wash sm:size-28"
                >
                  <img src={p.image} alt="" className="size-full object-contain" />
                </Link>
                <div className="flex min-w-0 flex-1 flex-col gap-2">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <Link
                        to="/urun/$sku"
                        params={{ sku: productSlug(p) }}
                        className="font-display text-xl leading-tight hover:underline"
                      >
                        {p.name}
                      </Link>
                      <p className="mt-1 flex items-center gap-2 text-sm text-fg-muted">
                        <ColorDot id={line.color} />
                        {color?.name} · {p.sku}
                      </p>
                    </div>
                    <p className="text-sm tabular-nums">{formatPrice(p.price * line.qty)}</p>
                  </div>
                  <div className="mt-auto flex items-center justify-between">
                    <QtyControl
                      value={line.qty}
                      onChange={(n) => setQty(line.sku, line.color, n)}
                    />
                    <button
                      type="button"
                      className="flex size-11 items-center justify-center text-fg-muted hover:text-danger"
                      aria-label="Kaldır"
                      onClick={() => remove(line.sku, line.color)}
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      </div>

      <aside className="h-fit border border-dashed border-border bg-bg-elevated p-5">
        <h2 className="font-display text-2xl">Özet</h2>
        <dl className="mt-4 space-y-2 text-sm">
          <div className="flex justify-between">
            <dt className="text-fg-muted">Ara toplam</dt>
            <dd className="tabular-nums">{formatPrice(subtotal)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-fg-muted">Kargo</dt>
            <dd className="tabular-nums">
              {shipping === 0 ? "Ücretsiz" : formatPrice(shipping)}
            </dd>
          </div>
        </dl>
        {remaining > 0 ? (
          <p className="mt-3 text-xs text-fg-muted">
            Ücretsiz kargo için {formatPrice(remaining)} kaldı.
          </p>
        ) : (
          <p className="mt-3 text-xs text-fg-muted">Kargo ücretsiz.</p>
        )}
        <div className="mt-4 flex justify-between border-t border-border pt-4 text-base">
          <span>Toplam</span>
          <span className="tabular-nums">{formatPrice(total)}</span>
        </div>
        <Link to="/odeme" className="mt-5 block">
          <Button className="w-full" size="lg">
            Ödemeye geç
          </Button>
        </Link>
        <Link to="/koleksiyon" className="mt-3 block text-center text-sm text-fg-muted hover:text-fg">
          Alışverişe dön
        </Link>
      </aside>
    </div>
  );
}
