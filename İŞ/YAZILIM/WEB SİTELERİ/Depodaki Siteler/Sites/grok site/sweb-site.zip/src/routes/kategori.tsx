import { createFileRoute, Link } from "@tanstack/react-router";
import { CATEGORIES, PRODUCTS } from "@/lib/products";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/kategori")({
  component: Categories,
  head: () =>
    pageHead({
      title: "Odalar",
      description: "Ofis, banyo, makyaj, mutfak, gardırop, giriş, yaşam, araç.",
      path: "/kategori",
    }),
});

const WASH = [
  "bg-p-krem",
  "bg-p-gri",
  "bg-p-lacivert",
  "bg-p-taba",
  "bg-p-bordo",
  "bg-p-siyah",
  "bg-p-krem",
  "bg-p-gri",
];

function Categories() {
  return (
    <div className="mx-auto max-w-[1400px] px-4 py-10">
      <p className="font-mono text-xs tracking-wide text-fg-muted uppercase">Odalar</p>
      <h1 className="mt-2 font-display text-4xl sm:text-5xl">Odalar</h1>
      <p className="mt-3 text-sm text-fg-muted">
        {CATEGORIES.length} oda · {PRODUCTS.length} parça
      </p>
      <ul className="mt-10 grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-4">
        {CATEGORIES.map((c, i) => {
          const items = PRODUCTS.filter((p) => p.category === c.id);
          const cover = items[0];
          return (
            <li key={c.id} className={`${WASH[i % WASH.length]} flex flex-col`}>
              <Link
                to="/kategori/$id"
                params={{ id: c.id }}
                className="group flex flex-1 flex-col"
              >
                {cover ? (
                  <img
                    src={cover.image}
                    alt=""
                    className="aspect-[4/3] w-full object-contain p-4 transition-opacity duration-200 group-hover:opacity-90"
                  />
                ) : null}
                <div className="mt-auto px-4 pb-5">
                  <p className="font-display text-2xl">{c.name}</p>
                  <p className="mt-1 text-sm text-fg-muted">{c.blurb}</p>
                  <p className="mt-2 font-mono text-xs text-fg-muted">{items.length} parça</p>
                </div>
              </Link>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
