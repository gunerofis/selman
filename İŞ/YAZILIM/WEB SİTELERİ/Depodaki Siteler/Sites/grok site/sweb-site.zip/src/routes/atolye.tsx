import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { BRAND } from "@/lib/brand";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/atolye")({
  component: Atelier,
  head: () =>
    pageHead({
      title: "Atölye",
      description: "Üretim, malzeme ve teslim. 3–5 iş günü hazır stok.",
      path: "/atolye",
    }),
});

function Atelier() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-14">
      <p className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">Atölye</p>
      <h1 className="mt-3 font-display text-4xl sm:text-5xl">
        Ürünlerin nasıl yapıldığı, hangi malzemeden ve hangi sürede.
      </h1>
      <div className="mt-8 grid grid-cols-3 gap-px border border-dashed border-border bg-border">
        {[
          ["/products/7043.png", "Ekmek kutusu"],
          ["/products/7012.png", "Ayakkabı bankı"],
          ["/products/7080.png", "Dizüstü folyo"],
        ].map(([src, alt]) => (
          <div key={src} className="bg-bg-wash">
            <img src={src} alt={alt} className="aspect-square w-full object-contain p-2" />
          </div>
        ))}
      </div>
      <div className="mt-10 space-y-5 text-base leading-relaxed text-fg-muted">
        <p>
          {BRAND.name}, evin ve masanın görünmeyen köşelerini — çekmeceyi, lavabo
          kenarını, giriş holünü — deriyle ele alan bir atölye. Parçalar 70xx ve
          71xx stok kodlarıyla üretilir; her biri sekiz renkte: espresso, siyah, krem,
          lacivert, gri, beyaz, taba ve bordo.
        </p>
        <p>
          Gövdeler deri ile kaplanır, içler süet veya keçe ile yumuşatılır. Döner
          mekanizmalar, damlama tepsileri ve menteşeler görünmez kalır; elde kalan
          şey form ve renk olur.
        </p>
        <p>
          Koleksiyon banyo, makyaj, mutfak, gardırop, giriş, yaşam, araç ve ofis
          masası için aynı elden, aynı paletten.
        </p>
      </div>
      <div className="mt-10 grid gap-6 sm:grid-cols-3">
        {[
          [
            "Malzeme",
            "Dış deri kaplama, iç keçe veya süet. İstenirse ahşap gövde, metal menteşe ve vida görünmez kalır. Sekiz renk sabit liste.",
          ],
          [
            "Üretim",
            "Kalıp, kaplama, dikiş, montaj. Hazır stok 3–5 iş günü. Ölçüye göre parça 10–15 iş günü. Elli adet ve üzeri 10–20 iş günü.",
          ],
          [
            "Bakım",
            "Nemli bez. Yağ, çözücü, buhar yok. Güneşe uzun süre bırakmayın. Damlama tepsisi çıkarılıp yıkanır.",
          ],
        ].map(([t, b]) => (
          <div key={t} className="border border-dashed border-border bg-bg-elevated p-5">
            <p className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">{t}</p>
            <p className="mt-3 text-sm leading-relaxed text-fg-muted">{b}</p>
          </div>
        ))}
      </div>
      <div className="mt-10 border border-dashed border-border bg-bg-elevated p-6">
        <p className="font-mono text-[11px] tracking-wide text-fg-muted uppercase">Süre</p>
        <dl className="mt-4 grid gap-4 text-sm sm:grid-cols-3">
          {[
            ["Hazır stok", "3–5 iş günü"],
            ["Ölçüye göre", "10–15 iş günü"],
            ["Kurumsal", "10–20 iş günü"],
          ].map(([k, v]) => (
            <div key={k}>
              <dt className="text-fg-muted">{k}</dt>
              <dd className="mt-1 font-mono">{v}</dd>
            </div>
          ))}
        </dl>
      </div>
      <p className="mt-8 text-sm text-fg-muted">{BRAND.atelier}</p>
      <div className="mt-10 flex flex-wrap gap-3">
        <Link to="/koleksiyon">
          <Button>Koleksiyona git</Button>
        </Link>
        <Link to="/tasarla">
          <Button variant="outline">Tasarımınızı gönderin</Button>
        </Link>
      </div>
    </div>
  );
}
