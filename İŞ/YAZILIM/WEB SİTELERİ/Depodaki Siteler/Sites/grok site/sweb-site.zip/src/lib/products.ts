export const COLORS = [
  { id: "espresso", name: "Espresso", swatch: "#3D2C26" },
  { id: "siyah", name: "Siyah", swatch: "#1A1918" },
  { id: "krem", name: "Krem", swatch: "#D8CFC3" },
  { id: "lacivert", name: "Lacivert", swatch: "#1E2A44" },
  { id: "gri", name: "Gri", swatch: "#6A6E72" },
  { id: "beyaz", name: "Beyaz", swatch: "#F3F1ED" },
  { id: "taba", name: "Taba", swatch: "#A66B3C" },
  { id: "bordo", name: "Bordo", swatch: "#6B2430" },
] as const;

export type ColorId = (typeof COLORS)[number]["id"];

/** Tile wash when a leather color is selected on the wall. */
export const PASTEL: Record<ColorId, string> = {
  espresso: "#EDE2DB",
  siyah: "#E3E0DC",
  krem: "#EFE6DA",
  lacivert: "#DDE1E6",
  gri: "#E4E5E2",
  beyaz: "#FDFAF6",
  taba: "#EDE2DB",
  bordo: "#E8DCDC",
};

export const CATEGORIES = [
  { id: "ofis", name: "Ofis", blurb: "Masa, evrak, şarj, imza." },
  { id: "banyo", name: "Banyo", blurb: "Lavabo, tıraş, ıslak hacim." },
  { id: "makyaj", name: "Makyaj", blurb: "Ayna, ruj, fırça." },
  { id: "mutfak", name: "Mutfak", blurb: "Tezgâh ve çekmece." },
  { id: "gardrop", name: "Gardırop", blurb: "Saat, kemer, günlük eşya." },
  { id: "giris", name: "Giriş", blurb: "Kapı, oturak, anahtar." },
  { id: "yasam", name: "Yaşam", blurb: "Sehpa, vitrin, koltuk." },
  { id: "arac", name: "Araç", blurb: "Koltuk arkası düzen." },
] as const;

export type CategoryId = (typeof CATEGORIES)[number]["id"];

/** Hub tiles skip Araç (tek parça); kategori filtresi ve alt bilgi durur. */
export const HUB_CATEGORIES = CATEGORIES.filter((c) => c.id !== "arac");

export const SERIES = [
  {
    id: "kompakt",
    name: "Kompakt masa",
    blurb: "Sümen, stand, tepsi, kulaklık.",
    image: "/products/set-kompakt.png",
  },
  {
    id: "aksesuar",
    name: "Masa aksesuar",
    blurb: "A4, evraklık, monitör, şarj.",
    image: "/products/set-aksesuar.png",
  },
  {
    id: "yonetici",
    name: "Yönetici masa",
    blurb: "Sümen, arşiv, imza, kaşe.",
    image: "/products/set-yonetici.png",
  },
] as const;

export type SeriesId = (typeof SERIES)[number]["id"];

export type Spec = { label: string; value: string };

export type Product = {
  sku: string;
  name: string;
  shortName: string;
  category: CategoryId;
  series?: SeriesId;
  price: number;
  image: string;
  tagline: string;
  description: string;
  features: string[];
  specs: Spec[];
  featured?: boolean;
};

const TR_SLUG: Record<string, string> = {
  ç: "c",
  ğ: "g",
  ı: "i",
  i: "i",
  ö: "o",
  ş: "s",
  ü: "u",
  â: "a",
  î: "i",
  û: "u",
};

export function slugify(input: string) {
  return input
    .split("")
    .map((ch) => TR_SLUG[ch] ?? TR_SLUG[ch.toLocaleLowerCase("tr")] ?? ch)
    .join("")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export function productSlug(p: Product) {
  return slugify(p.name);
}

export const CATEGORY_ALIASES: Record<string, CategoryId> = {
  calisma: "ofis",
  "yatak-odasi": "gardrop",
  ev: "yasam",
};

export function resolveCategory(id: string | undefined): CategoryId | undefined {
  if (!id) return undefined;
  if (CATEGORIES.some((c) => c.id === id)) return id as CategoryId;
  return CATEGORY_ALIASES[id];
}


export const PRODUCTS: Product[] = [
  {
    sku: "7002",
    name: "Komodin organizeri",
    shortName: "Komodin",
    category: "gardrop",
    price: 3890,
    image: "/products/7002.png",
    tagline: "Telefon, gözlük, saat — çekmece altta.",
    description:
      "Yatak başı için üç bölmeli valet. Telefon yuvası, gözlük yatağı, saat yastığı; altta günlük eşya çekmecesi.",
    features: [
      "Eğimli telefon yuvası",
      "Gözlük ve saat bölmesi",
      "Alt çekmece",
      "Kaymaz taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "240 × 160 × 90 mm" },
      { label: "Ağırlık", value: "380 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7003",
    name: "Koltuk arkası organizeri",
    shortName: "Koltuk arkası",
    category: "arac",
    price: 4490,
    image: "/products/7003.png",
    tagline: "Koltuk arkasına asılır, tabla açılır.",
    description:
      "Başlık kayışlı koltuk arkası panel. Üst cep, açılır tabla, alt dergi cebi. Arka koltuk için sabit durak.",
    features: [
      "Başlık kayışı",
      "Açılır orta tabla",
      "Üst ve alt cep",
      "Koltuk kumaşına sürtünmeyen astar",
    ],
    specs: [
      { label: "Dış ölçü", value: "420 × 580 mm" },
      { label: "Ağırlık", value: "680 g" },
      { label: "Montaj", value: "Başlık kayışı" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7004",
    name: "Mama standı",
    shortName: "Mama",
    category: "yasam",
    price: 5290,
    image: "/products/7004.png",
    tagline: "İki çelik kap, mama ve fırça yeri.",
    description:
      "Yükseltilmiş mama ve su kabı. Arkada mama poşeti, fırça ve poşet rulosu; yanda tasma kancası.",
    features: [
      "İki paslanmaz kap",
      "Mama ve fırça bölmesi",
      "Tasma kancası",
      "Yükseltilmiş taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "420 × 280 × 260 mm" },
      { label: "Ağırlık", value: "2100 g" },
      { label: "Kap", value: "2 × çelik" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7005",
    name: "Tıraş istasyonu",
    shortName: "Tıraş",
    category: "banyo",
    price: 4790,
    image: "/products/7005.png",
    tagline: "Fırça, tarak, makine, iki pompa.",
    description:
      "Lavabo kenarı tıraş durağı. Fırça ve tarak yuvaları, makine yatağı, iki pompa deliği, altta çekmeceli tepsi.",
    features: [
      "Fırça ve tarak yuvası",
      "İki pompa deliği",
      "Makine yatağı",
      "Çekmeceli alt tepsi",
    ],
    specs: [
      { label: "Dış ölçü", value: "280 × 180 × 220 mm" },
      { label: "Ağırlık", value: "620 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7006",
    name: "Piknik çantası",
    shortName: "Piknik",
    category: "yasam",
    price: 5690,
    image: "/products/7006.png",
    tagline: "İki bardak yuvası, bölmeli gövde.",
    description:
      "Kulplu, kapaklı piknik kutusu. Yan kanatlarda iki bardak yuvası, içte iki bölme. Kapak açık durur.",
    features: [
      "İki yan bardak yuvası",
      "İç bölme",
      "Taşıma kulpu",
      "Menteşeli kapak",
    ],
    specs: [
      { label: "Dış ölçü", value: "320 × 180 × 120 mm" },
      { label: "Ağırlık", value: "740 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7007",
    name: "Askılı konsol",
    shortName: "Konsol",
    category: "giris",
    price: 8990,
    image: "/products/7007.png",
    tagline: "İki kanca, çekmece, alt raf.",
    description:
      "Giriş holü için dikey oturak. Üstte iki kanca, oturma altında çekmece, tabanda ayakkabı rafı.",
    features: [
      "İki üst kanca",
      "Yastıklı oturma",
      "Çekmece",
      "Alt ayakkabı rafı",
    ],
    specs: [
      { label: "Dış ölçü", value: "380 × 1100 × 320 mm" },
      { label: "Ağırlık", value: "4200 g" },
      { label: "Yük", value: "110 kg" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7008",
    name: "Yatak cebi",
    shortName: "Yatak cebi",
    category: "yasam",
    price: 2490,
    image: "/products/7008.png",
    tagline: "Telefon üstte, gözlük ve kablo altta.",
    description:
      "Yatak veya kanepe kenarına asılan cep. Üst raf telefona, orta cep gözlüğe, alt cep kabloya.",
    features: [
      "Kenara asılır",
      "Telefon rafı",
      "Gözlük cebi",
      "Kablo cebi",
    ],
    specs: [
      { label: "Dış ölçü", value: "180 × 320 mm" },
      { label: "Ağırlık", value: "220 g" },
      { label: "Montaj", value: "Kenar kancası" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7009",
    name: "Kolçak organizeri",
    shortName: "Kolçak",
    category: "yasam",
    price: 2790,
    image: "/products/7009.png",
    tagline: "Bardak yuvası, iki kumanda cebi.",
    description:
      "Kanepe koluna geçen tepsi. Bardak yuvası, iki kumanda cebi, düz üst yüzey.",
    features: [
      "Kolçağa geçer",
      "Bardak yuvası",
      "İki kumanda cebi",
      "Düz tepsi yüzeyi",
    ],
    specs: [
      { label: "Dış ölçü", value: "320 × 180 mm" },
      { label: "Ağırlık", value: "260 g" },
      { label: "Uyum", value: "Geniş kolçak" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7010",
    name: "Koltuk yan sehpası",
    shortName: "Sehpa",
    category: "yasam",
    price: 6490,
    image: "/products/7010.png",
    tagline: "Bardak, telefon, yan cepte kitap.",
    description:
      "Kanepe altına giren C form. Üstte bardak ve telefon yuvası, gövdede dergi cebi.",
    features: [
      "C form taban",
      "Bardak yuvası",
      "Telefon yuvası",
      "Yan kitap cebi",
    ],
    specs: [
      { label: "Dış ölçü", value: "280 × 560 × 320 mm" },
      { label: "Ağırlık", value: "2100 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7011",
    name: "Saat standı",
    shortName: "Saat standı",
    category: "giris",
    price: 4290,
    image: "/products/7011.png",
    tagline: "Kanca, saat yastığı, gözlük tepsisi.",
    description:
      "Dikey valet. İki kanca, yanda saat yastığı, ortada kart cebi, altta iki tepsi.",
    features: [
      "İki pirinç kanca",
      "Saat yastığı",
      "Kart cebi",
      "İki kademeli tepsi",
    ],
    specs: [
      { label: "Dış ölçü", value: "160 × 280 × 140 mm" },
      { label: "Ağırlık", value: "410 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7012",
    name: "Ayakkabı bankı",
    shortName: "Ayakkabı bankı",
    category: "giris",
    price: 9890,
    image: "/products/7012.png",
    tagline: "Otur, çekmeceyi aç, alt rafa koy.",
    description:
      "Giriş bankı. Yastıklı oturma, iç çekmece, altta iki çift ayakkabı rafı, yanda çekecek cebi.",
    features: [
      "Yastıklı oturma",
      "İç çekmece",
      "Alt ayakkabı rafı",
      "Çekecek cebi",
    ],
    specs: [
      { label: "Dış ölçü", value: "900 × 480 × 360 mm" },
      { label: "Ağırlık", value: "6400 g" },
      { label: "Yük", value: "120 kg" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7015",
    name: "Anahtarlık panosu",
    shortName: "Anahtar",
    category: "giris",
    price: 3290,
    image: "/products/7015.png",
    tagline: "Altı kanca, altta tepsi.",
    description:
      "Duvar veya tezgâh panosu. Altı pirinç kanca, üstte isim plakası, altta ince tepsi.",
    features: [
      "6 pirinç kanca",
      "İsim plakası",
      "Alt tepsi",
      "Duvar veya masa",
    ],
    specs: [
      { label: "Dış ölçü", value: "280 × 240 × 40 mm" },
      { label: "Ağırlık", value: "380 g" },
      { label: "Kanca", value: "6 adet" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7016",
    name: "Çöp kutusu",
    shortName: "Çöp kutusu",
    category: "ofis",
    series: "yonetici",
    price: 4590,
    image: "/products/7016.png",
    tagline: "Eğik kapak, ön kapak, poşet içinde.",
    description:
      "Kapaklı atık kutusu. Eğik üst kapak, önde servis kapağı, iç poşet yuvası.",
    features: [
      "Eğik üst kapak",
      "Ön servis kapağı",
      "İç poşet yuvası",
      "Kaymaz taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "220 × 380 × 220 mm" },
      { label: "Ağırlık", value: "980 g" },
      { label: "Hacim", value: "12 L" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7017",
    name: "Masaüstü istasyonu",
    shortName: "Masaüstü",
    category: "ofis",
    series: "kompakt",
    price: 3690,
    image: "/products/7017.png",
    tagline: "Kalem, kart, kâğıt, telefon.",
    description:
      "Çalışma masası için yatay istasyon. Kalem kadehi, iki kart yuvası, kâğıt tepsisi, eğimli telefon yatağı.",
    features: [
      "Kalem kadehi",
      "İki kart yuvası",
      "Kâğıt tepsisi",
      "Telefon yatağı",
    ],
    specs: [
      { label: "Dış ölçü", value: "320 × 120 × 80 mm" },
      { label: "Ağırlık", value: "290 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7018",
    name: "Valet kutusu",
    shortName: "Valet",
    category: "gardrop",
    price: 4490,
    image: "/products/7018.png",
    tagline: "Saat, yüzük, anahtar, nakit.",
    description:
      "Kapak içi cepli valet kutusu. Saat yastığı, yüzük yuvaları, anahtar ve nakit bölmesi, pasaport tepsisi.",
    features: [
      "Saat yastığı ve yüzük rulosu",
      "Anahtar, nakit ve pasaport bölmeleri",
      "Kapak içi cep",
      "Süet astar",
    ],
    specs: [
      { label: "Dış ölçü", value: "320 × 180 × 80 mm" },
      { label: "Ağırlık", value: "420 g" },
      { label: "Malzeme", value: "Deri, süet astar" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7020",
    name: "Dizüstü tepsi",
    shortName: "Dizüstü",
    category: "yasam",
    price: 5490,
    image: "/products/7020.png",
    tagline: "Kucakta laptop, yanda şarj cebi.",
    description:
      "Diz üstü çalışma tepsisi. Düz deri yüzey, kalem kanalı, yan cepte adaptör yuvası.",
    features: [
      "Düz çalışma yüzeyi",
      "Kalem kanalı",
      "Adaptör cebi",
      "Kavisli bacaklar",
    ],
    specs: [
      { label: "Dış ölçü", value: "560 × 320 × 80 mm" },
      { label: "Ağırlık", value: "740 g" },
      { label: "Uyum", value: "13–16 inç" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7023",
    name: "Çocuk kitaplığı",
    shortName: "Kitaplık",
    category: "yasam",
    price: 6890,
    image: "/products/7023.png",
    tagline: "Kapaklar önde, üç raf.",
    description:
      "Duvara asılan üç raflı resimli kitap standı. Kapaklar görünür kalır. Yumuşak köşe, sığ profil.",
    features: [
      "Üç kademeli ön kapak rafı",
      "Duvara asılır",
      "Yumuşak köşe",
      "Oyuncak nişi",
    ],
    specs: [
      { label: "Dış ölçü", value: "920 × 520 × 140 mm" },
      { label: "Ağırlık", value: "3800 g" },
      { label: "Kapasite", value: "12–16 kitap" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7025",
    name: "Model araba rafı",
    shortName: "Raf",
    category: "yasam",
    price: 5990,
    image: "/products/7025.png",
    tagline: "Dokuz göz, üç kademe.",
    description:
      "1:64 ölçek model arabalar için üç katlı, dokuz gözlü masaüstü vitrin. Eğimli cephe, deri taban.",
    features: [
      "9 göz, 3 kademe",
      "Eğimli sergi cephesi",
      "Deri kaplı taban",
      "Masaüstü veya raf",
    ],
    specs: [
      { label: "Dış ölçü", value: "380 × 280 × 180 mm" },
      { label: "Ağırlık", value: "620 g" },
      { label: "Ölçek", value: "1:64" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7027",
    name: "Katlanır oturak",
    shortName: "Katlanır",
    category: "giris",
    price: 7490,
    image: "/products/7027.png",
    tagline: "Açılır, oturulur, kapanır.",
    description:
      "Duvara menteşeli katlanır oturak. Açıkken oturma yüzeyi, kapalıyken ince panel.",
    features: [
      "Duvara menteşeli",
      "Kapalıyken 80 mm",
      "Yastıklı oturma",
      "Gizli bağlantı",
    ],
    specs: [
      { label: "Dış ölçü", value: "Açık 620 × 480 × 360 mm" },
      { label: "Ağırlık", value: "2900 g" },
      { label: "Yük", value: "120 kg" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7028",
    name: "Makyaj organizeri",
    shortName: "Makyaj",
    category: "makyaj",
    price: 10990,
    image: "/products/7028.png",
    tagline: "Ayna, ruj ızgarası, iki çekmece.",
    description:
      "Masaüstü makyaj istasyonu. Kaldırılır ayna, ruj ızgarası, fırça kadehleri, iki alt çekmece.",
    features: [
      "Kaldırılır ayna",
      "Ruj ızgarası",
      "Fırça kadehleri",
      "İki çekmece",
    ],
    specs: [
      { label: "Dış ölçü", value: "360 × 280 × 220 mm" },
      { label: "Ağırlık", value: "540 g" },
      { label: "Kapasite", value: "40+ ürün" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7029",
    name: "Baharat istasyonu",
    shortName: "Baharat",
    category: "mutfak",
    price: 7890,
    image: "/products/7029.png",
    tagline: "Kavanoz, kaşık, peçete, yağlık.",
    description:
      "Tezgâh baharat ünitesi. İki kavanoz rafı, kaşık kadehi, peçete mili, yağlık yuvası, alt çekmece.",
    features: [
      "İki kavanoz rafı",
      "Kaşık kadehi",
      "Peçete mili",
      "Yağlık ve çekmece",
    ],
    specs: [
      { label: "Dış ölçü", value: "420 × 280 × 260 mm" },
      { label: "Ağırlık", value: "860 g" },
      { label: "Kapasite", value: "10 kavanoz" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7030",
    name: "Banyo lavabo istasyonu",
    shortName: "Banyo lavabo",
    category: "banyo",
    price: 6190,
    image: "/products/7030.png",
    tagline: "Pompa, fırça, havlu, çekmece.",
    description:
      "Lavabo üstü bakım durağı. Pompa rafı, iki fırça kadehi, orta tepsi, havlu rafı, alt çekmece.",
    features: [
      "Pompa rafı",
      "İki fırça kadehi",
      "Havlu rafı",
      "Alt çekmece",
    ],
    specs: [
      { label: "Dış ölçü", value: "360 × 200 × 180 mm" },
      { label: "Ağırlık", value: "710 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7031",
    name: "Şarap standı",
    shortName: "Şarap",
    category: "yasam",
    price: 9890,
    image: "/products/7031.png",
    tagline: "Üç şişe, dört kadeh, bir karaf.",
    description:
      "Asılı kadeh rayı, karaf platformu, üç şişelik eğimli yatak ve alt çekmece.",
    features: [
      "4 kadeh asma rayı",
      "3 şişelik eğimli yuva",
      "Karaf sehpası",
      "Açacak çekmecesi",
    ],
    specs: [
      { label: "Dış ölçü", value: "420 × 380 × 280 mm" },
      { label: "Ağırlık", value: "920 g" },
      { label: "Kapasite", value: "3 şişe + 4 kadeh" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7032",
    name: "Şemsiyelik",
    shortName: "Şemsiye",
    category: "giris",
    price: 5490,
    image: "/products/7032.png",
    tagline: "Uzun tüp, yan cep, damlama tepsisi.",
    description:
      "Çift tüp: uzun şemsiye ve baston. Yan cepte katlanır şemsiye, altta damlama çekmecesi.",
    features: [
      "Uzun şemsiye tüpü",
      "Katlanır şemsiye cebi",
      "Damlama tepsisi",
      "Havalandırma dilimleri",
    ],
    specs: [
      { label: "Dış ölçü", value: "280 × 520 × 180 mm" },
      { label: "Ağırlık", value: "1100 g" },
      { label: "Kapasite", value: "2 uzun + 1 kompakt" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7033",
    name: "Şarj istasyonu",
    shortName: "Şarj",
    category: "ofis",
    series: "aksesuar",
    price: 6990,
    image: "/products/7033.png",
    tagline: "Tablet, kablo, adaptör, çekmece.",
    description:
      "Masaüstü cihaz durağı. Üç kademeli tablet yuvası, kablo kadehleri, adaptör tepsisi, alt çekmece.",
    features: [
      "Üç kademeli cihaz yuvası",
      "Kablo kadehleri",
      "Adaptör tepsisi",
      "Alt çekmece",
    ],
    specs: [
      { label: "Dış ölçü", value: "320 × 220 × 180 mm" },
      { label: "Ağırlık", value: "640 g" },
      { label: "Uyum", value: "Telefon ve tablet" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7034",
    name: "Saat ve kemer tepsisi",
    shortName: "Saat-kemer",
    category: "gardrop",
    price: 8490,
    image: "/products/7034.png",
    tagline: "Kemer, saat, bileklik, kol düğmesi.",
    description:
      "Gardırop çekmecesine oturan organizer. Dört kemer yuvası, dört saat yastığı, bileklik kanalları.",
    features: [
      "4 kemer bölmesi",
      "4 saat yastığı",
      "Bileklik kanalları",
      "Kol düğmesi tepsisi",
    ],
    specs: [
      { label: "Dış ölçü", value: "800 × 400 × 80 mm" },
      { label: "Ağırlık", value: "780 g" },
      { label: "Uyum", value: "Standart çekmece" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7035",
    name: "Makyaj rafı",
    shortName: "Makyaj rafı",
    category: "makyaj",
    price: 12490,
    image: "/products/7035.png",
    tagline: "Ayna, raf, on ruj yuvası.",
    description:
      "Ortada kemer ayna, iki yanda kavisli raflar, altta on ruj yuvası ve fırça kadehleri.",
    features: [
      "Merkezi ayna",
      "Kademeli krem rafları",
      "10 ruj yuvası",
      "İki fırça kadehi",
    ],
    specs: [
      { label: "Dış ölçü", value: "580 × 420 × 180 mm" },
      { label: "Ağırlık", value: "960 g" },
      { label: "Kapasite", value: "30+ ürün" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7036",
    name: "Ruj kulesi",
    shortName: "Ruj kulesi",
    category: "makyaj",
    price: 8990,
    image: "/products/7036.png",
    tagline: "360 derece, ruj ızgarası.",
    description:
      "Dönen silindirik makyaj kulesi. Izgaralı ruj cepheleri, fırça nişi, palet rafı, tepede ayna.",
    features: [
      "360° döner taban",
      "Izgara ruj yuvaları",
      "Fırça ve palet nişi",
      "Çıkarılabilir ayna",
    ],
    specs: [
      { label: "Dış ölçü", value: "Ø 240 × 320 mm" },
      { label: "Ağırlık", value: "480 g" },
      { label: "Kapasite", value: "40+ ruj" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7037",
    name: "Makyaj kutusu",
    shortName: "Kutu",
    category: "makyaj",
    price: 11890,
    image: "/products/7037.png",
    tagline: "Kapak ayna, iki çekmece.",
    description:
      "İki çekmeceli, menteşeli ayna kapaklı makyaj sandığı. Üst tepside ruj, pudra ve fırça bölmeleri.",
    features: [
      "Tam boy ayna kapak",
      "Bölmeli üst tepsi",
      "İki çekmece",
      "Süet astar",
    ],
    specs: [
      { label: "Dış ölçü", value: "420 × 180 × 160 mm" },
      { label: "Ağırlık", value: "520 g" },
      { label: "Çekmece", value: "2 adet" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7038",
    name: "Duvar makyaj aynası",
    shortName: "Duvar ayna",
    category: "makyaj",
    price: 9490,
    image: "/products/7038.png",
    tagline: "Kapak açılır, ayna çıkar.",
    description:
      "Aşağı katlanan kapaklı duvar makyaj istasyonu. Kapak açılınca ayna, ruj sırası, fırça kadehi.",
    features: [
      "Gaz pistonlu kapak",
      "Merkezi ayna",
      "Yan tüp cepleri",
      "Kapak içi ruj yuvası",
    ],
    specs: [
      { label: "Dış ölçü", value: "Kapalı 420 × 480 × 100 mm" },
      { label: "Ağırlık", value: "1400 g" },
      { label: "Montaj", value: "Duvar askısı" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7040",
    name: "Kesme tahtası standı",
    shortName: "Tahta standı",
    category: "mutfak",
    price: 5590,
    image: "/products/7040.png",
    tagline: "Tahta, tepsi, merdane, havlu.",
    description:
      "Dikey kesme tahtası ve tepsi standı. Üç kanal, merdane kadehi, önde havlu çubuğu.",
    features: [
      "Üç dikey kanal",
      "Merdane kadehi",
      "Havlu çubuğu",
      "Kaymaz taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "360 × 280 × 220 mm" },
      { label: "Ağırlık", value: "720 g" },
      { label: "Kapasite", value: "4–6 tahta" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7041",
    name: "Evye organizeri",
    shortName: "Evye",
    category: "mutfak",
    price: 4890,
    image: "/products/7041.png",
    tagline: "Sabun, sünger, fırça, havlu.",
    description:
      "İki pompa yuvası, fırça kadehi, sünger rafı, havlu çubuğu ve önde damlama tepsisi.",
    features: [
      "İki sabun pompası yuvası",
      "Fırça ve sünger bölmesi",
      "Havlu çubuğu",
      "Çıkarılabilir damlama tepsisi",
    ],
    specs: [
      { label: "Dış ölçü", value: "280 × 160 × 180 mm" },
      { label: "Ağırlık", value: "380 g" },
      { label: "Bakım", value: "Tepsi çıkarılır" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7042",
    name: "Baharatlık",
    shortName: "Baharatlık",
    category: "mutfak",
    price: 5790,
    image: "/products/7042.png",
    tagline: "Döner taban, iki raf, poşet cebi.",
    description:
      "Kare döner baharat kulesi. İki rafta kavanozlar, yanda poşet cebi, tepede ölçü kapları.",
    features: [
      "360° döner taban",
      "İki kavanoz rafı",
      "Poşet baharat cebi",
      "Tepede 4 ölçü kabı",
    ],
    specs: [
      { label: "Dış ölçü", value: "240 × 240 × 320 mm" },
      { label: "Ağırlık", value: "540 g" },
      { label: "Kapasite", value: "6 kavanoz" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7043",
    name: "Ekmek kutusu",
    shortName: "Ekmek",
    category: "mutfak",
    price: 7890,
    image: "/products/7043.png",
    tagline: "Ekmek, meyve, üç kavanoz.",
    description:
      "Havalandırmalı rulo kapaklı ekmek bölmesi, kırıntı tepsisi, iki meyve yuvası ve üç kavanoz yuvası.",
    features: [
      "Rulo kapak",
      "Kırıntı tepsisi",
      "Meyve yuvaları",
      "Üç kavanoz bölmesi",
    ],
    specs: [
      { label: "Dış ölçü", value: "520 × 280 × 240 mm" },
      { label: "Ağırlık", value: "1100 g" },
      { label: "Kapasite", value: "1 somun + 3 kavanoz" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7044",
    name: "Mutfak folyo kutusu",
    shortName: "Mutfak folyo",
    category: "mutfak",
    price: 4290,
    image: "/products/7044.png",
    tagline: "Dört rulo, mandal tepsisi.",
    description:
      "Çekmece içi rulo organizer. Folyo, pişirme kâğıdı, streç ve peçete için dört kanal.",
    features: [
      "4 rulo kanalı",
      "Deri stoperler",
      "Mandal bölmesi",
      "Yedek rulo tepsisi",
    ],
    specs: [
      { label: "Dış ölçü", value: "420 × 320 × 80 mm" },
      { label: "Ağırlık", value: "320 g" },
      { label: "Uyum", value: "Standart çekmece" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7045",
    name: "Saç aleti standı",
    shortName: "Saç",
    category: "banyo",
    price: 5490,
    image: "/products/7045.png",
    tagline: "Fön, maşa, tarak, kablo.",
    description:
      "Eğimli fön yuvası, üç silindir ve önde pens tepsisi. Isıya dayanıklı iç kılıf, kablo kanalları.",
    features: [
      "Eğimli fön yuvası",
      "Üç ısı kalkanlı silindir",
      "Pens tepsisi",
      "Kablo yönlendirme",
    ],
    specs: [
      { label: "Dış ölçü", value: "320 × 220 × 180 mm" },
      { label: "Ağırlık", value: "460 g" },
      { label: "Uyarı", value: "Alet soğuduktan sonra" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7046",
    name: "Çekmece düzenleyici",
    shortName: "Çekmece",
    category: "banyo",
    price: 3890,
    image: "/products/7046.png",
    tagline: "Tüp, jilet, fırça — dar çekmece.",
    description:
      "Dar çekmece için uzun, bölmeli organizer. Tüp ve şişe kanalları, jilet ve diş fırçası yuvaları.",
    features: [
      "Dar profil",
      "Tüp ve şişe kanalları",
      "Jilet / fırça yuvaları",
      "Uç tepsi",
    ],
    specs: [
      { label: "Dış ölçü", value: "380 × 100 × 60 mm" },
      { label: "Ağırlık", value: "180 g" },
      { label: "Uyum", value: "Dar çekmece" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7047",
    name: "Banyo duvar rafı",
    shortName: "Duvar banyo",
    category: "banyo",
    price: 6490,
    image: "/products/7047.png",
    tagline: "Pompa, rulo, fırça, havlu barı.",
    description:
      "İki katlı duvar organizer. Üstte pompa şişeleri, altta havlu ruloları ve diş fırçası yuvaları.",
    features: [
      "İki katlı açık raf",
      "Diş fırçası yuvaları",
      "Havlu barı",
      "Duvar montaj plakası",
    ],
    specs: [
      { label: "Dış ölçü", value: "380 × 420 × 140 mm" },
      { label: "Ağırlık", value: "640 g" },
      { label: "Montaj", value: "Askı seti" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7048",
    name: "Banyo organizeri",
    shortName: "Banyo",
    category: "banyo",
    price: 7290,
    image: "/products/7048.png",
    tagline: "İki raf, orta kadeh, döner taban.",
    description:
      "Silindirik, açık cepheli döner organizer. Üst ve alt raflarda şişeler, ortada tarak ve jilet kadehi.",
    features: [
      "360° döner taban",
      "Açık cephe, iki kat",
      "Orta kadeh",
      "Kaymaz taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "Ø 260 × 280 mm" },
      { label: "Ağırlık", value: "520 g" },
      { label: "Kapasite", value: "10–14 şişe" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7049",
    name: "Tuvalet kâğıtlığı",
    shortName: "Kâğıtlık",
    category: "banyo",
    price: 5990,
    image: "/products/7049.png",
    tagline: "Aktif rulo, yedek istif, mendil cebi.",
    description:
      "Dikey kule: yanda aktif rulo, içeride yedek istif, önde ıslak mendil cebi, tepede kutu mendil.",
    features: [
      "Aktif rulo mili",
      "İç yedek kulesi",
      "Islak mendil cebi",
      "Tepede kutu mendil",
    ],
    specs: [
      { label: "Dış ölçü", value: "220 × 480 × 180 mm" },
      { label: "Ağırlık", value: "480 g" },
      { label: "Kapasite", value: "1 + 4 rulo" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7014",
    name: "Mektupluk",
    shortName: "Mektupluk",
    category: "giris",
    price: 3490,
    image: "/products/7014.webp",
    tagline: "Evrak cebi, kalemlik, anahtar askısı.",
    description:
      "Duvara asılan giriş panosu. Üstte evrak cebi, yanda kalemlik, altta üç anahtar kancası.",
    features: [
      "Duvara asılır",
      "Evrak cebi",
      "Kalem yuvası",
      "Üç anahtar kancası",
    ],
    specs: [
      { label: "Dış ölçü", value: "280 × 360 × 80 mm" },
      { label: "Ağırlık", value: "280 g" },
      { label: "Montaj", value: "Askı seti" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7024",
    name: "Ütü masası dolabı",
    shortName: "Ütü dolabı",
    category: "yasam",
    price: 9890,
    image: "/products/7024.webp",
    tagline: "Ütü tahtası içeride, kumaş üstte.",
    description:
      "Kapaklı dikey dolap. İçeride katlanır ütü tahtası, üstte kumaş rulosu ve askı çubuğu.",
    features: [
      "İç ütü tahtası",
      "Üst kumaş rulosu",
      "Askı çubuğu",
      "Kapaklı gövde",
    ],
    specs: [
      { label: "Dış ölçü", value: "420 × 1600 × 280 mm" },
      { label: "Ağırlık", value: "8500 g" },
      { label: "Tahta", value: "Katlanır" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7026",
    name: "Robot süpürge altlığı",
    shortName: "Süpürge",
    category: "yasam",
    price: 4590,
    image: "/products/7026.webp",
    tagline: "Süpürge üstte, fırça çekmecesi altta.",
    description:
      "Yuvarlak durak. Robot süpürge üstte şarj olur, alt çekmecede yedek fırça ve bez durur.",
    features: [
      "Üst durak tepsisi",
      "Alt çekmece",
      "Fırça ve bez bölmesi",
      "Kaymaz taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "Ø 380 × 120 mm" },
      { label: "Ağırlık", value: "720 g" },
      { label: "Uyum", value: "Yuvarlak robot" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7051",
    name: "Giriş panosu",
    shortName: "Pano",
    category: "giris",
    price: 4290,
    image: "/products/7051.webp",
    tagline: "Anahtar, evrak, kalem — duvarda.",
    description:
      "Duvar panosu. Üstte açık raf, ortada evrak cepleri, altta kanca sırası ve kalem yuvası.",
    features: [
      "Üst açık raf",
      "Evrak cepleri",
      "Kanca sırası",
      "Kalem yuvası",
    ],
    specs: [
      { label: "Dış ölçü", value: "480 × 620 × 90 mm" },
      { label: "Ağırlık", value: "680 g" },
      { label: "Montaj", value: "Askı seti" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7052",
    name: "Giriş dolabı",
    shortName: "Dolap",
    category: "giris",
    price: 14990,
    image: "/products/7052.webp",
    tagline: "Askı, oturak, ayakkabı, çekmece.",
    description:
      "Giriş holü dolabı. Üstte askı çubuğu, ortada oturma, altta ayakkabı rafları ve yan çekmece.",
    features: [
      "Askı çubuğu",
      "Yastıklı oturma",
      "Ayakkabı rafları",
      "Yan çekmece",
    ],
    specs: [
      { label: "Dış ölçü", value: "900 × 1800 × 380 mm" },
      { label: "Ağırlık", value: "9800 g" },
      { label: "Yük", value: "110 kg" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7054",
    name: "Kahve istasyonu",
    shortName: "Kahve",
    category: "mutfak",
    price: 8690,
    image: "/products/7054.webp",
    tagline: "Makine, fincan, çekirdek, tepsi.",
    description:
      "Tezgâh kahve ünitesi. Üstte makine durak, asılı fincanlar, çekirdek kavanozları ve damlama tepsisi.",
    features: [
      "Makine durak",
      "Fincan askısı",
      "Kavanoz yuvaları",
      "Damlama tepsisi",
    ],
    specs: [
      { label: "Dış ölçü", value: "520 × 380 × 420 mm" },
      { label: "Ağırlık", value: "1600 g" },
      { label: "Kapasite", value: "6 fincan" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7055",
    name: "Kahve karuseli",
    shortName: "Karusel",
    category: "mutfak",
    price: 4290,
    image: "/products/7055.webp",
    tagline: "Döner gövde, kapsül ve fincan.",
    description:
      "Döner kahve karuseli. Kapsül yuvaları, fincan kadehi, üstte küçük kavanoz tepsisi.",
    features: [
      "360° döner taban",
      "Kapsül yuvaları",
      "Fincan kadehi",
      "Üst tepsi",
    ],
    specs: [
      { label: "Dış ölçü", value: "Ø 240 × 280 mm" },
      { label: "Ağırlık", value: "540 g" },
      { label: "Kapasite", value: "24 kapsül" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7060",
    name: "Figür rafı",
    shortName: "Figür rafı",
    category: "yasam",
    price: 8990,
    image: "/products/7060.png",
    tagline: "Beş kat, duvara asılır.",
    description:
      "Duvar figür rafı. Beş açık raf, yan yan menteşe plakası. Minyatür, araba ve küçük obje için.",
    features: [
      "Beş açık raf",
      "Duvar montaj plakası",
      "Alçak ön dudak",
      "Sıralı dizilim",
    ],
    specs: [
      { label: "Dış ölçü", value: "900 × 420 × 80 mm" },
      { label: "Ağırlık", value: "820 g" },
      { label: "Raf", value: "5 kat" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7062",
    name: "Başucu şarj istasyonu",
    shortName: "Başucu şarj",
    category: "gardrop",
    price: 4290,
    image: "/products/7062.png",
    tagline: "Gözlük, telefon, kulaklık, kalem.",
    description:
      "Yatak başı valet. Gözlük tepsisi, dik telefon yuvası, kulaklık yatağı, kalem gözü; arkada kablo çıkışı.",
    features: [
      "Gözlük tepsisi",
      "Dik telefon yuvası",
      "Kulaklık yatağı",
      "Kablo çıkışı",
    ],
    specs: [
      { label: "Dış ölçü", value: "280 × 160 × 90 mm" },
      { label: "Ağırlık", value: "360 g" },
      { label: "Kablo", value: "Arka kanal" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7063",
    name: "Duvar hol panosu",
    shortName: "Hol panosu",
    category: "giris",
    price: 3890,
    image: "/products/7063.png",
    tagline: "Cüzdan, posta, üç kanca.",
    description:
      "Kapı içi duvar panosu. Üst cep cüzdan, yan cep posta, alt rafta kulaklık; üç kanca anahtar için.",
    features: [
      "Cüzdan cebi",
      "Posta cebi",
      "Üç anahtar kancası",
      "Duvar montaj",
    ],
    specs: [
      { label: "Dış ölçü", value: "320 × 220 × 70 mm" },
      { label: "Ağırlık", value: "420 g" },
      { label: "Montaj", value: "Askı seti" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7065",
    name: "Lavabo tepsisi",
    shortName: "Lavabo tepsisi",
    category: "banyo",
    price: 4490,
    image: "/products/7065.png",
    tagline: "Pompa, fırça, havlu, pamuk.",
    description:
      "Lavabo kenarı organizer. İki pompa yuvası, fırça kadehi, pamuk kavanozu ve katlı havlu yeri.",
    features: [
      "İki pompa yuvası",
      "Fırça kadehi",
      "Pamuk kavanozu yeri",
      "Havlu bölmesi",
    ],
    specs: [
      { label: "Dış ölçü", value: "320 × 220 × 90 mm" },
      { label: "Ağırlık", value: "280 g" },
      { label: "Bakım", value: "Nemli bez" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7066",
    name: "Yağ ve baharatlık",
    shortName: "Yağ-baharat",
    category: "mutfak",
    price: 5290,
    image: "/products/7066.png",
    tagline: "İki şişe, altı kavanoz.",
    description:
      "Tezgâh baharat ve yağ ünitesi. Solda iki yağ şişesi yuvası, sağda iki katlı altı kavanoz rafı.",
    features: [
      "İki şişe yuvası",
      "İki kat kavanoz rafı",
      "Kaymaz taban",
      "Tezgâha oturur",
    ],
    specs: [
      { label: "Dış ölçü", value: "320 × 180 × 140 mm" },
      { label: "Ağırlık", value: "480 g" },
      { label: "Kapasite", value: "2 şişe + 6 kavanoz" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7067",
    name: "Saat ve gözlük tepsisi",
    shortName: "Saat-gözlük",
    category: "gardrop",
    price: 6490,
    image: "/products/7067.png",
    tagline: "Üç saat, iki gözlük, takı.",
    description:
      "Çekmece veya komodin tepsisi. Üç saat yastığı, iki gözlük yatağı, zincir ve küpe gözleri.",
    features: [
      "Üç saat yastığı",
      "İki gözlük yatağı",
      "Takı bölmeleri",
      "Süet iç",
    ],
    specs: [
      { label: "Dış ölçü", value: "380 × 260 × 40 mm" },
      { label: "Ağırlık", value: "220 g" },
      { label: "Kapasite", value: "3 saat + 2 gözlük" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7068",
    name: "Oyun kolu tepsisi",
    shortName: "Oyun tepsisi",
    category: "yasam",
    price: 3990,
    image: "/products/7068.png",
    tagline: "İki kol, kablo, kutu oyun.",
    description:
      "Sehpa üstü oyun tepsisi. İki kol yuvası, kablo gözü, arkada kutu oyun dayanağı.",
    features: [
      "İki kol yuvası",
      "Kablo gözü",
      "Oyun dayanağı",
      "Kaymaz taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "420 × 220 × 80 mm" },
      { label: "Ağırlık", value: "340 g" },
      { label: "Kapasite", value: "2 kol + 4 kutu" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7069",
    name: "Fotoğraf tepsisi",
    shortName: "Foto tepsi",
    category: "yasam",
    price: 5490,
    image: "/products/7069.png",
    tagline: "Gövde, iki objektif, kart.",
    description:
      "Çekmece fotoğraf tepsisi. Gövde yuvası, iki objektif kapağı gözü, pil ve hafıza kartı bölmesi.",
    features: [
      "Gövde yuvası",
      "İki objektif gözü",
      "Pil bölmesi",
      "Kart yuvası",
    ],
    specs: [
      { label: "Dış ölçü", value: "360 × 260 × 70 mm" },
      { label: "Ağırlık", value: "260 g" },
      { label: "Uyum", value: "Aynasız gövde" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7070",
    name: "Dikiş istasyonu",
    shortName: "Dikiş",
    category: "yasam",
    price: 4290,
    image: "/products/7070.png",
    tagline: "Makas, iplik, iğnelik.",
    description:
      "Masa dikiş organizeri. Makas kadehi, altı iplik yuvası, iğnelik ve şerit metre gözü.",
    features: [
      "Makas kadehi",
      "İplik yuvaları",
      "İğnelik gözü",
      "Şerit metre bölmesi",
    ],
    specs: [
      { label: "Dış ölçü", value: "280 × 180 × 120 mm" },
      { label: "Ağırlık", value: "380 g" },
      { label: "Kapasite", value: "6 iplik + makas" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7072",
    name: "Hediye paketleme istasyonu",
    shortName: "Paketleme",
    category: "yasam",
    price: 4990,
    image: "/products/7072.png",
    tagline: "Rulo, poşet, makas, bant.",
    description:
      "Masa paketleme ünitesi. Üç rulo yuvası, poşet ve kâğıt rafı, makas kadehi, altta bant ve kurdela.",
    features: [
      "Üç rulo yuvası",
      "Poşet rafı",
      "Makas kadehi",
      "Bant ve kurdela gözü",
    ],
    specs: [
      { label: "Dış ölçü", value: "260 × 220 × 280 mm" },
      { label: "Ağırlık", value: "440 g" },
      { label: "Rulo", value: "3 adet" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7073",
    name: "Bere ve eldiven tepsisi",
    shortName: "Bere-eldiven",
    category: "gardrop",
    price: 4690,
    image: "/products/7073.png",
    tagline: "İki eldiven, bere, atkı.",
    description:
      "Çekmece kış tepsisi. İki eldiven gözü, orta bere yuvası, üstte iki atkı kanalı.",
    features: [
      "İki eldiven gözü",
      "Bere yuvası",
      "İki atkı kanalı",
      "Çekmeceye oturur",
    ],
    specs: [
      { label: "Dış ölçü", value: "380 × 260 × 80 mm" },
      { label: "Ağırlık", value: "240 g" },
      { label: "Uyum", value: "Standart çekmece" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7075",
    name: "Oje tepsisi",
    shortName: "Oje",
    category: "makyaj",
    price: 3890,
    image: "/products/7075.png",
    tagline: "Sekiz oje, pamuk, törpü.",
    description:
      "Makyaj oje tepsisi. Sekiz şişe yuvası, pamuk kavanozu yeri, ön olukta törpü ve makas.",
    features: [
      "8 oje yuvası",
      "Pamuk kavanozu yeri",
      "Törpü oluğu",
      "Makas yatağı",
    ],
    specs: [
      { label: "Dış ölçü", value: "280 × 180 × 50 mm" },
      { label: "Ağırlık", value: "160 g" },
      { label: "Kapasite", value: "8 şişe" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7076",
    name: "Sofra organizeri",
    shortName: "Sofra",
    category: "mutfak",
    price: 4790,
    image: "/products/7076.png",
    tagline: "Peçete, çatal, bıçak, değirmen.",
    description:
      "Masa sofra caddysi. Peçete rafı, kaşık-çatal-bıçak gözleri, yanda tuz ve karabiber değirmeni.",
    features: [
      "Peçete rafı",
      "Üç çatal-bıçak gözü",
      "Değirmen yuvası",
      "Keçe astar",
    ],
    specs: [
      { label: "Dış ölçü", value: "280 × 180 × 160 mm" },
      { label: "Ağırlık", value: "320 g" },
      { label: "Kapasite", value: "4 kişilik takım" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7077",
    name: "Atıştırmalık standı",
    shortName: "Atıştırmalık",
    category: "mutfak",
    price: 5590,
    image: "/products/7077.png",
    tagline: "Üç kat poşet rafı.",
    description:
      "Tezgâh atıştırmalık standı. Üç kademeli açık raf; kuruyemiş ve kurabiye poşetleri dik durur.",
    features: [
      "Üç kademeli raf",
      "Açık ön",
      "Kaymaz taban",
      "Poşet dayanağı",
    ],
    specs: [
      { label: "Dış ölçü", value: "320 × 240 × 180 mm" },
      { label: "Ağırlık", value: "480 g" },
      { label: "Kapasite", value: "12 poşet" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7078",
    name: "Giysi bakım istasyonu",
    shortName: "Giysi bakım",
    category: "gardrop",
    price: 4290,
    image: "/products/7078.png",
    tagline: "Fırça, tüy rulo, koku topu.",
    description:
      "Gardırop bakım tepsisi. Fırça ve tüy rulo yuvaları, koku topu gözü, sprey kadehi, bez bölmesi.",
    features: [
      "Fırça yuvası",
      "Tüy rulo yuvası",
      "Koku topu gözü",
      "Sprey kadehi",
    ],
    specs: [
      { label: "Dış ölçü", value: "320 × 180 × 120 mm" },
      { label: "Ağırlık", value: "360 g" },
      { label: "Uyum", value: "Raf veya çekmece" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7079",
    name: "Ayakkabı boya tepsisi",
    shortName: "Boya tepsisi",
    category: "giris",
    price: 4490,
    image: "/products/7079.png",
    tagline: "İki fırça, iki kutu, bez.",
    description:
      "Ayakkabı bakımı tepsisi. İki fırça yatağı, iki kutu boya gözü, bez rulosu, bağcık ve kıl fırça kadehi.",
    features: [
      "İki fırça yatağı",
      "İki kutu gözü",
      "Bez rulosu",
      "Bağcık bölmesi",
    ],
    specs: [
      { label: "Dış ölçü", value: "380 × 220 × 70 mm" },
      { label: "Ağırlık", value: "280 g" },
      { label: "Uyum", value: "Çekmece veya raf" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7080",
    name: "Dizüstü folyo",
    shortName: "Dizüstü folyo",
    category: "ofis",
    series: "aksesuar",
    price: 6990,
    image: "/products/7080.png",
    tagline: "15,6 inç, evrak, kart.",
    description:
      "Fermuarlı dizüstü folyo. Sol göz 15,6 inç dizüstü, sağda evrak cebi, dört kart yuvası ve kalem lastiği.",
    features: [
      "Çevre fermuar",
      "15,6 inç yuva",
      "4 kart yuvası",
      "Evrak cebi",
    ],
    specs: [
      { label: "Dış ölçü", value: "360 × 275 × 25 mm" },
      { label: "Ağırlık", value: "420 g" },
      { label: "Uyum", value: "13–16 inç" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7081",
    name: "Cüzdan istasyonu",
    shortName: "Cüzdan",
    category: "giris",
    price: 4290,
    image: "/products/7081.png",
    tagline: "Dört cüzdan, anahtar, kartlık.",
    description:
      "Giriş cüzdan ünitesi. Arkada evrak dayanağı, dört dik cüzdan gözü, önde kartlık ve anahtar tepsisi.",
    features: [
      "Dört dik cüzdan gözü",
      "Evrak dayanağı",
      "Kartlık tepsisi",
      "Anahtar gözü",
    ],
    specs: [
      { label: "Dış ölçü", value: "280 × 180 × 120 mm" },
      { label: "Ağırlık", value: "380 g" },
      { label: "Kapasite", value: "4 cüzdan" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7083",
    name: "Çanta rafı",
    shortName: "Çanta rafı",
    category: "gardrop",
    price: 6490,
    image: "/products/7083.png",
    tagline: "Üç göz, çanta dik durur.",
    description:
      "Gardırop çanta rafı. Üç açık göz; el çantası, omuz çantası ve cüzdan dik durur. Raf veya duvar.",
    features: [
      "Üç açık göz",
      "Alçak ön dudak",
      "Raf veya duvar",
      "Kaymaz taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "520 × 220 × 180 mm" },
      { label: "Ağırlık", value: "720 g" },
      { label: "Kapasite", value: "3 çanta" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7101",
    name: "Sümen",
    shortName: "Sümen",
    category: "ofis",
    series: "kompakt",
    price: 5490,
    image: "/products/7101.png",
    tagline: "Masa yüzeyi, tek parça.",
    description:
      "Dikdörtgen deri sümen. Dizüstü, defter ve fare için düz çalışma yüzeyi.",
    features: [
      "Kaymaz taban",
      "Yuvarlak köşe",
      "Deri üst, sert taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "600 × 300 × 8 mm" },
      { label: "Ağırlık", value: "620 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7102",
    name: "Telefon standı",
    shortName: "Telefon",
    category: "ofis",
    series: "kompakt",
    price: 2490,
    image: "/products/7102.png",
    tagline: "Ekranı dik tutar.",
    description:
      "Eğimli telefon ve küçük tablet standı. Altta kablo kanalı.",
    features: [
      "Eğimli yaslanma",
      "Alt dudak",
      "Kablo geçişi",
    ],
    specs: [
      { label: "Dış ölçü", value: "90 × 140 × 110 mm" },
      { label: "Ağırlık", value: "180 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7103",
    name: "El desteği",
    shortName: "El desteği",
    category: "ofis",
    series: "kompakt",
    price: 2290,
    image: "/products/7103.png",
    tagline: "Klavye önünde yaslanır.",
    description:
      "Uzun, yastıklı el desteği. Yazarken bileği yükseltir.",
    features: [
      "Yastıklı üst",
      "Sert taban",
      "Dar profil",
    ],
    specs: [
      { label: "Dış ölçü", value: "360 × 70 × 18 mm" },
      { label: "Ağırlık", value: "210 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7104",
    name: "Kalem tepsisi",
    shortName: "Kalem tepsisi",
    category: "ofis",
    series: "kompakt",
    price: 1690,
    image: "/products/7104.png",
    tagline: "Kalem ve cetvel yan yana.",
    description:
      "Uzun, sığ tepsi. Kalem, kurşun ve küçük araçlar.",
    features: [
      "Tek göz",
      "Yuvarlak uç",
      "Sığ derinlik",
    ],
    specs: [
      { label: "Dış ölçü", value: "260 × 50 × 18 mm" },
      { label: "Ağırlık", value: "90 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7105",
    name: "Fare altlığı",
    shortName: "Fare altlığı",
    category: "ofis",
    series: "kompakt",
    price: 1490,
    image: "/products/7105.png",
    tagline: "Kare, düz yüzey.",
    description:
      "Kare deri altlık. Fare veya fincan için.",
    features: [
      "Düz üst",
      "Sert kenar",
      "Kaymaz taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "110 × 110 × 8 mm" },
      { label: "Ağırlık", value: "70 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7106",
    name: "Kart tutucu",
    shortName: "Kart tutucu",
    category: "ofis",
    series: "kompakt",
    price: 1290,
    image: "/products/7106.png",
    tagline: "Kartvizit dik durur.",
    description:
      "Yarımküre form, ortada yarık. Kartvizit veya küçük not.",
    features: [
      "Merkez yarığı",
      "Ağır taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "Ø 45 × 35 mm" },
      { label: "Ağırlık", value: "40 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7107",
    name: "Saat yastığı",
    shortName: "Saat yastığı",
    category: "ofis",
    series: "kompakt",
    price: 2490,
    image: "/products/7107.png",
    tagline: "Saat yastıkta, tepside.",
    description:
      "Kare tepsi içinde silindir yastık. Kol saati için.",
    features: [
      "Silindir yastık",
      "Kare tepsi",
    ],
    specs: [
      { label: "Dış ölçü", value: "90 × 90 × 55 mm" },
      { label: "Ağırlık", value: "120 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7108",
    name: "Küçük tepsi",
    shortName: "Küçük tepsi",
    category: "ofis",
    series: "kompakt",
    price: 1690,
    image: "/products/7108.png",
    tagline: "Bozuk para, yüzük, klips.",
    description:
      "Kare, sığ yakalama tepsisi.",
    features: [
      "Tek göz",
      "Yükseltilmiş kenar",
    ],
    specs: [
      { label: "Dış ölçü", value: "90 × 90 × 20 mm" },
      { label: "Ağırlık", value: "80 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7109",
    name: "Kartvizit tepsisi",
    shortName: "Kartvizit",
    category: "ofis",
    series: "kompakt",
    price: 1890,
    image: "/products/7109.png",
    tagline: "Önde parmak boşluğu.",
    description:
      "Dikdörtgen kartvizit yatağı. Önde alma boşluğu.",
    features: [
      "Ön oyuk",
      "Sığ gövde",
      "20–30 kart",
    ],
    specs: [
      { label: "Dış ölçü", value: "100 × 70 × 22 mm" },
      { label: "Ağırlık", value: "70 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7110",
    name: "Kare tepsi",
    shortName: "Kare tepsi",
    category: "ofis",
    series: "kompakt",
    price: 2190,
    image: "/products/7110.png",
    tagline: "Anahtar, kulaklık, klips.",
    description:
      "Orta boy kare tepsi. Günlük küçük eşya.",
    features: [
      "Tek göz",
      "Yüksek kenar",
    ],
    specs: [
      { label: "Dış ölçü", value: "130 × 130 × 25 mm" },
      { label: "Ağırlık", value: "140 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7111",
    name: "Üç bölmeli tepsi",
    shortName: "Üç bölme",
    category: "ofis",
    series: "kompakt",
    price: 2890,
    image: "/products/7111.png",
    tagline: "Telefon, kulaklık, kablo.",
    description:
      "Bir uzun, iki kare göz. Şarj ve küçük eşya için.",
    features: [
      "3 göz",
      "Uzun + iki kare",
      "Yüksek kenar",
    ],
    specs: [
      { label: "Dış ölçü", value: "140 × 140 × 30 mm" },
      { label: "Ağırlık", value: "180 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7112",
    name: "Kulaklık standı",
    shortName: "Kulaklık",
    category: "ofis",
    series: "kompakt",
    price: 3990,
    image: "/products/7112.png",
    tagline: "Kulaklık askıda durur.",
    description:
      "Kavisli üst yastık, dik gövde, kare taban.",
    features: [
      "Kavisli askı",
      "Dik mil",
      "Kare taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "110 × 110 × 220 mm" },
      { label: "Ağırlık", value: "310 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7114",
    name: "A4 tepsisi",
    shortName: "A4 tepsisi",
    category: "ofis",
    series: "aksesuar",
    price: 3290,
    image: "/products/7114.png",
    tagline: "Tek kat, ince form.",
    description:
      "A4 evrak tepsisi. Evrakları düz tutar.",
    features: [
      "A4 uyum",
      "İnce profil",
      "Önde alma kenarı",
    ],
    specs: [
      { label: "Dış ölçü", value: "320 × 230 × 25 mm" },
      { label: "Ağırlık", value: "280 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7115",
    name: "Valet tepsisi",
    shortName: "Valet tepsisi",
    category: "ofis",
    series: "aksesuar",
    price: 2990,
    image: "/products/7115.png",
    tagline: "Anahtar, cüzdan, saat, kulaklık.",
    description:
      "Dikdörtgen masaüstü valet. Cep içeriği için tek göz.",
    features: [
      "Tek göz",
      "Yükseltilmiş kenar",
      "Kaymaz taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "220 × 160 × 25 mm" },
      { label: "Ağırlık", value: "220 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7116",
    name: "Dikey evraklık",
    shortName: "Evraklık",
    category: "ofis",
    series: "aksesuar",
    price: 4290,
    image: "/products/7116.png",
    tagline: "Dosya ve katalog dik durur.",
    description:
      "Eğimli ağızlı dikey evrak tutucu. A4 dosya, katalog, klasör.",
    features: [
      "Eğimli ağız",
      "Dik gövde",
      "A4 uyum",
    ],
    specs: [
      { label: "Dış ölçü", value: "160 × 250 × 220 mm" },
      { label: "Ağırlık", value: "480 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7117",
    name: "Monitör yükseltici",
    shortName: "Monitör",
    category: "ofis",
    series: "aksesuar",
    price: 6490,
    image: "/products/7117.png",
    tagline: "Ekran yükselir, altı boş kalır.",
    description:
      "Monitör sehpası. Alt boşlukta klavye veya kablo.",
    features: [
      "Üst platform",
      "Açık alt",
      "Kaymaz ayak",
    ],
    specs: [
      { label: "Dış ölçü", value: "300 × 200 × 80 mm" },
      { label: "Ağırlık", value: "720 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7118",
    name: "Dizüstü standı",
    shortName: "Dizüstü",
    category: "ofis",
    series: "aksesuar",
    price: 5490,
    image: "/products/7118.png",
    tagline: "Ekranı eğer, altı açılır.",
    description:
      "Eğimli dizüstü standı. Havalandırma boşluğu bırakır.",
    features: [
      "Eğimli yüzey",
      "Ön dudak",
      "Açık taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "280 × 240 × 80 mm" },
      { label: "Ağırlık", value: "540 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7119",
    name: "Şarj tepsisi",
    shortName: "Şarj tepsisi",
    category: "ofis",
    series: "aksesuar",
    price: 3990,
    image: "/products/7119.png",
    tagline: "Telefon, kablo, kulaklık.",
    description:
      "Üç gözlü şarj durağı. Telefon, kablo ucu ve kulaklık.",
    features: [
      "3 göz",
      "Telefon yatağı",
      "Kablo kanalı",
    ],
    specs: [
      { label: "Dış ölçü", value: "180 × 140 × 30 mm" },
      { label: "Ağırlık", value: "240 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7120",
    name: "Defter standı",
    shortName: "Defter standı",
    category: "ofis",
    series: "aksesuar",
    price: 3690,
    image: "/products/7120.png",
    tagline: "Defter eğik durur.",
    description:
      "Ajanda ve not defteri standı. Yazmayı kolaylaştırır.",
    features: [
      "Eğimli yüzey",
      "Ön dudak",
    ],
    specs: [
      { label: "Dış ölçü", value: "240 × 180 × 120 mm" },
      { label: "Ağırlık", value: "360 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7121",
    name: "Dikey kalemlik",
    shortName: "Kalemlik",
    category: "ofis",
    series: "aksesuar",
    price: 2290,
    image: "/products/7121.png",
    tagline: "Kalem, makas, cetvel dik.",
    description:
      "Kare kesitli dikey kalemlik.",
    features: [
      "Tek göz",
      "Kare ağız",
      "Ağır taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "70 × 70 × 110 mm" },
      { label: "Ağırlık", value: "160 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7122",
    name: "Mendil kılıfı",
    shortName: "Mendil kılıfı",
    category: "ofis",
    series: "aksesuar",
    price: 2790,
    image: "/products/7122.png",
    tagline: "Kutu mendili örter.",
    description:
      "Standart kutu mendil kılıfı. Üstte çekme ağzı.",
    features: [
      "Üst oval ağız",
      "Kutu uyumu",
    ],
    specs: [
      { label: "Dış ölçü", value: "240 × 130 × 80 mm" },
      { label: "Ağırlık", value: "280 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7123",
    name: "Gözlük tepsisi",
    shortName: "Gözlük tepsisi",
    category: "ofis",
    series: "aksesuar",
    price: 1890,
    image: "/products/7123.png",
    tagline: "Gözlük çizilmeden durur.",
    description:
      "Dar dikdörtgen tepsi. Gözlük için yumuşak taban.",
    features: [
      "Dar form",
      "Sığ derinlik",
      "Yumuşak iç",
    ],
    specs: [
      { label: "Dış ölçü", value: "160 × 70 × 18 mm" },
      { label: "Ağırlık", value: "80 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7131",
    name: "Ana sümen",
    shortName: "Ana sümen",
    category: "ofis",
    series: "yonetici",
    price: 6990,
    image: "/products/7131.png",
    tagline: "Masanın zemin parçası.",
    description:
      "Geniş dikdörtgen sümen. Yazı ve fare alanı.",
    features: [
      "Geniş yüzey",
      "Kaymaz taban",
      "Yuvarlak köşe",
    ],
    specs: [
      { label: "Dış ölçü", value: "700 × 350 × 8 mm" },
      { label: "Ağırlık", value: "780 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7132",
    name: "Evrak platformu",
    shortName: "Evrak platformu",
    category: "ofis",
    series: "yonetici",
    price: 4290,
    image: "/products/7132.png",
    tagline: "Çalışma evrakı önde durur.",
    description:
      "Arkası yükseltilmiş evrak platformu.",
    features: [
      "Arka dayanak",
      "Düz taban",
      "A4 uyum",
    ],
    specs: [
      { label: "Dış ölçü", value: "320 × 230 × 40 mm" },
      { label: "Ağırlık", value: "360 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7133",
    name: "Evrak arşiv rafı",
    shortName: "Arşiv rafı",
    category: "ofis",
    series: "yonetici",
    price: 7990,
    image: "/products/7133.png",
    tagline: "Üç kat evrak.",
    description:
      "Üç raflı evrak arşivi. Gelen, işlenen, giden.",
    features: [
      "3 raf",
      "Açık ön",
      "A4 uyum",
    ],
    specs: [
      { label: "Dış ölçü", value: "330 × 250 × 220 mm" },
      { label: "Ağırlık", value: "1100 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
    featured: true,
  },
  {
    sku: "7134",
    name: "İmza istasyonu",
    shortName: "İmza",
    category: "ofis",
    series: "yonetici",
    price: 2690,
    image: "/products/7134.png",
    tagline: "Kalem yatay durur.",
    description:
      "Tek kalem yatağı. İmza kalemi için.",
    features: [
      "Tek kanal",
      "Yastıklı yatak",
    ],
    specs: [
      { label: "Dış ölçü", value: "180 × 70 × 20 mm" },
      { label: "Ağırlık", value: "120 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7135",
    name: "Yazışma tepsisi",
    shortName: "Yazışma",
    category: "ofis",
    series: "yonetici",
    price: 2490,
    image: "/products/7135.png",
    tagline: "Mektup ve not kâğıdı.",
    description:
      "Dikdörtgen sığ yazışma tepsisi.",
    features: [
      "Tek göz",
      "Sığ kenar",
    ],
    specs: [
      { label: "Dış ölçü", value: "220 × 120 × 20 mm" },
      { label: "Ağırlık", value: "160 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7136",
    name: "Kişisel eşya tepsisi",
    shortName: "Kişisel tepsi",
    category: "ofis",
    series: "yonetici",
    price: 3290,
    image: "/products/7136.png",
    tagline: "Saat, yüzük, klips.",
    description:
      "Kenarlı kişisel eşya tepsisi.",
    features: [
      "Yüksek kenar",
      "Tek göz",
    ],
    specs: [
      { label: "Dış ölçü", value: "180 × 120 × 30 mm" },
      { label: "Ağırlık", value: "200 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7137",
    name: "Kol saati yastığı",
    shortName: "Kol saati",
    category: "ofis",
    series: "yonetici",
    price: 2190,
    image: "/products/7137.png",
    tagline: "Kol saati yastıkta.",
    description:
      "Silindir saat yastığı, kare taban.",
    features: [
      "Silindir form",
      "Kare taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "70 × 70 × 50 mm" },
      { label: "Ağırlık", value: "80 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7138",
    name: "Gözlük dinlendirici",
    shortName: "Gözlük",
    category: "ofis",
    series: "yonetici",
    price: 1990,
    image: "/products/7138.png",
    tagline: "Gözlük köprüde durur.",
    description:
      "Kavisli gözlük dinlendirme.",
    features: [
      "Çift kavis",
      "Yumuşak üst",
    ],
    specs: [
      { label: "Dış ölçü", value: "140 × 50 × 30 mm" },
      { label: "Ağırlık", value: "70 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7139",
    name: "Kartvizit haznesi",
    shortName: "Kartvizit",
    category: "ofis",
    series: "yonetici",
    price: 2690,
    image: "/products/7139.png",
    tagline: "Kartlar kapaklı durur.",
    description:
      "Kapaklı kartvizit kutusu, önde alma ağzı.",
    features: [
      "Kapak",
      "Ön ağız",
      "40 kart",
    ],
    specs: [
      { label: "Dış ölçü", value: "100 × 70 × 40 mm" },
      { label: "Ağırlık", value: "110 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7140",
    name: "Toplantı kart standı",
    shortName: "Kart standı",
    category: "ofis",
    series: "yonetici",
    price: 1890,
    image: "/products/7140.png",
    tagline: "İsim kartı dik durur.",
    description:
      "Tek yuvalı toplantı kartı standı.",
    features: [
      "Tek yarık",
      "Ağır taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "90 × 40 × 40 mm" },
      { label: "Ağırlık", value: "60 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7141",
    name: "Bloknot tutucu",
    shortName: "Bloknot",
    category: "ofis",
    series: "yonetici",
    price: 2290,
    image: "/products/7141.png",
    tagline: "Küp bloknot oturur.",
    description:
      "Kare bloknot yatağı.",
    features: [
      "Kare yuva",
      "9×9 bloknot",
    ],
    specs: [
      { label: "Dış ölçü", value: "100 × 100 × 25 mm" },
      { label: "Ağırlık", value: "90 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7142",
    name: "Zarf tutucu",
    shortName: "Zarf tutucu",
    category: "ofis",
    series: "yonetici",
    price: 2890,
    image: "/products/7142.png",
    tagline: "Zarf ve evrak dik.",
    description:
      "İki kanatlı zarf ve evrak tutucu.",
    features: [
      "Çift kanat",
      "Dik duruş",
    ],
    specs: [
      { label: "Dış ölçü", value: "160 × 70 × 80 mm" },
      { label: "Ağırlık", value: "140 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7143",
    name: "Kalem köprüsü",
    shortName: "Kalem köprüsü",
    category: "ofis",
    series: "yonetici",
    price: 2490,
    image: "/products/7143.png",
    tagline: "İki kalem yan yana.",
    description:
      "İki kanallı kalem köprüsü.",
    features: [
      "2 kanal",
      "Uzun form",
    ],
    specs: [
      { label: "Dış ölçü", value: "180 × 60 × 18 mm" },
      { label: "Ağırlık", value: "100 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7144",
    name: "Kaşe istasyonu",
    shortName: "Kaşe",
    category: "ofis",
    series: "yonetici",
    price: 3290,
    image: "/products/7144.png",
    tagline: "Kaşe, mürekkep, sünger.",
    description:
      "Üç gözlü kaşe istasyonu. Yuvarlak ve kare yuvalar.",
    features: [
      "3 göz",
      "Yuvarlak + kare",
      "Sünger yuvası",
    ],
    specs: [
      { label: "Dış ölçü", value: "180 × 90 × 30 mm" },
      { label: "Ağırlık", value: "160 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7145",
    name: "Not defteri platformu",
    shortName: "Not platformu",
    category: "ofis",
    series: "yonetici",
    price: 2790,
    image: "/products/7145.png",
    tagline: "Kapaklı defter altta.",
    description:
      "Toplantı not defteri platformu, alt boşluk.",
    features: [
      "Üst düzlem",
      "Alt boşluk",
    ],
    specs: [
      { label: "Dış ölçü", value: "180 × 110 × 30 mm" },
      { label: "Ağırlık", value: "180 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7146",
    name: "Evrak sabitleyici",
    shortName: "Sabitleyici",
    category: "ofis",
    series: "yonetici",
    price: 2290,
    image: "/products/7146.png",
    tagline: "Kâğıt ağırlıkla durur.",
    description:
      "Dikdörtgen evrak ağırlığı.",
    features: [
      "Ağır gövde",
      "Düz alt",
    ],
    specs: [
      { label: "Dış ölçü", value: "160 × 50 × 25 mm" },
      { label: "Ağırlık", value: "220 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7147",
    name: "Dosya desteği",
    shortName: "Dosya desteği",
    category: "ofis",
    series: "yonetici",
    price: 2990,
    image: "/products/7147.png",
    tagline: "Dosya arkadan dayanır.",
    description:
      "Tek dayanaklı dosya desteği.",
    features: [
      "Dikey dayanak",
      "Geniş taban",
    ],
    specs: [
      { label: "Dış ölçü", value: "220 × 80 × 80 mm" },
      { label: "Ağırlık", value: "200 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7148",
    name: "Gelen evrak tepsisi",
    shortName: "Gelen evrak",
    category: "ofis",
    series: "yonetici",
    price: 2390,
    image: "/products/7148.png",
    tagline: "Gelen evrak ayrı durur.",
    description:
      "Sığ dikdörtgen gelen evrak tepsisi.",
    features: [
      "Tek göz",
      "Sığ kenar",
    ],
    specs: [
      { label: "Dış ölçü", value: "240 × 100 × 20 mm" },
      { label: "Ağırlık", value: "150 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7149",
    name: "Giden evrak tepsisi",
    shortName: "Giden evrak",
    category: "ofis",
    series: "yonetici",
    price: 2390,
    image: "/products/7149.png",
    tagline: "Giden evrak ayrı durur.",
    description:
      "Sığ dikdörtgen giden evrak tepsisi.",
    features: [
      "Tek göz",
      "Sığ kenar",
    ],
    specs: [
      { label: "Dış ölçü", value: "240 × 100 × 20 mm" },
      { label: "Ağırlık", value: "150 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
  {
    sku: "7150",
    name: "Masa düzen çubuğu",
    shortName: "Düzen çubuğu",
    category: "ofis",
    series: "yonetici",
    price: 3490,
    image: "/products/7150.png",
    tagline: "Kalem, kart, mühür bir hatta.",
    description:
      "Uzun masa düzeni: kapak, kalem kanalı, yastık.",
    features: [
      "3 bölge",
      "Kalem kanalı",
      "Uç yastık",
    ],
    specs: [
      { label: "Dış ölçü", value: "280 × 70 × 25 mm" },
      { label: "Ağırlık", value: "180 g" },
      { label: "Renk", value: "8 seçenek" },
    ],
  },
];

export const PRODUCT_COUNT = PRODUCTS.length;

/** Homepage wall: 21 SKUs (center first). Extra tiles hide below 768 / 1440. */
export const WALL_SKUS = [
  "7043",
  "7069",
  "7060",
  "7083",
  "7067",
  "7054",
  "7036",
  "7068",
  "7080",
  "7012",
  "7048",
  "7007",
  "7065",
  "7075",
  "7015",
  "7076",
  "7052",
  "7073",
  "7131",
  "7047",
  "7062",
] as const;

export const FREE_SHIPPING_FROM = 5000;
export const SHIPPING_FEE = 149;

const SLUG_TO_SKU: Record<string, string> = {
  "sarj-standi": "7033",
  "sarj-istasyonu": "7033",
  "basucu-sarj-istasyonu": "7062",
  "tezgaah-organizeri": "7029",
  "tezgah-organizeri": "7029",
  "masa-organizeri": "7017",
  "tablet-ve-saat-standi": "7011",
  "basucu-valesi": "7062",
  "duvar-telefon-cebi": "7063",
  "saat-kutusu": "7034",
  "folyo-duzenleyici": "7044",
  "lavabo-istasyonu": "7030",
  "lavabo-tepsisi": "7065",
  "dizustu-folyo": "7080",
};

export function getProduct(id: string) {
  const key = decodeURIComponent(id).trim();
  const aliased = SLUG_TO_SKU[key.toLowerCase()];
  if (aliased) return PRODUCTS.find((p) => p.sku === aliased);
  return (
    PRODUCTS.find((p) => p.sku === key) ??
    PRODUCTS.find((p) => productSlug(p) === key.toLowerCase())
  );
}

export function getColor(id: ColorId) {
  return COLORS.find((c) => c.id === id);
}

export function productsByCategory(id: CategoryId) {
  return PRODUCTS.filter((p) => p.category === id);
}

export function featuredProducts() {
  return PRODUCTS.filter((p) => p.featured);
}

export function productsBySeries(id: SeriesId) {
  return PRODUCTS.filter((p) => p.series === id);
}

export function seriesTotal(id: SeriesId) {
  return productsBySeries(id).reduce((sum, p) => sum + p.price, 0);
}

export function getSeries(id: SeriesId | undefined) {
  return SERIES.find((s) => s.id === id);
}

export function foldTr(s: string) {
  return s
    .toLocaleLowerCase("tr")
    .replace(/ı/g, "i")
    .replace(/ş/g, "s")
    .replace(/ğ/g, "g")
    .replace(/ü/g, "u")
    .replace(/ö/g, "o")
    .replace(/ç/g, "c")
    .replace(/â/g, "a");
}

const JOB_EXPAND: Record<string, string[]> = {
  sarj: ["sarj", "kablo"],
  baharat: ["baharat", "baharatlik"],
  gozluk: ["gozluk"],
  dizustu: ["dizustu", "laptop"],
  laptop: ["dizustu", "laptop"],
  folyo: ["folyo", "rulo"],
  lavabo: ["lavabo"],
};

export function matchesQuery(p: Product, q: string) {
  const raw = foldTr(q.trim());
  if (!raw) return true;
  const words = raw.split(/\s+/).filter(Boolean);
  const hay = foldTr(
    [
      p.name,
      p.shortName,
      p.sku,
      p.tagline,
      p.description,
      p.features.join(" "),
      p.category,
      p.series ?? "",
    ].join(" "),
  );
  return words.every((w) => {
    const expanded = JOB_EXPAND[w] ?? [w];
    return expanded.some((term) => hay.includes(term));
  });
}

export function searchProducts(q: string, limit = 8) {
  const needle = q.trim();
  if (!needle) return PRODUCTS.slice(0, limit);
  return PRODUCTS.filter((p) => matchesQuery(p, needle)).slice(0, limit);
}

export function neighborsInCategory(sku: string) {
  const current = getProduct(sku);
  if (!current) return { prev: null as Product | null, next: null as Product | null };
  const list = PRODUCTS.filter((p) => p.category === current.category);
  const i = list.findIndex((p) => p.sku === current.sku);
  return {
    prev: i > 0 ? list[i - 1] : null,
    next: i >= 0 && i < list.length - 1 ? list[i + 1] : null,
  };
}

export function productPath(p: Product) {
  return `/urun/${productSlug(p)}`;
}

export function specGrams(p: Product) {
  const row = p.specs.find((s) => s.label === "Ağırlık");
  if (!row) return "—";
  if (/kg/i.test(row.value)) {
    const n = Number(row.value.replace(",", ".").replace(/[^\d.]/g, ""));
    if (Number.isFinite(n)) return `${Math.round(n * 1000)} g`;
  }
  return row.value;
}

export function relatedProducts(sku: string, limit = 4) {
  const current = getProduct(sku);
  if (!current) return PRODUCTS.slice(0, limit);
  const tokens = foldTr(`${current.name} ${current.tagline}`)
    .split(/\s+/)
    .filter((w) => w.length > 3);
  const scored = PRODUCTS.filter((p) => p.sku !== current.sku).map((p) => {
    let score = 0;
    if (p.category === current.category) score += 6;
    if (current.series && p.series === current.series) score += 5;
    const hay = foldTr(`${p.name} ${p.tagline} ${p.features.join(" ")}`);
    for (const t of tokens) if (hay.includes(t)) score += 2;
    return { p, score };
  });
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, limit).map((x) => x.p);
}
