import { COLORS, type ColorId } from "@/lib/products";
import { cn } from "@/lib/utils";

type Props = {
  value: ColorId;
  onChange: (id: ColorId) => void;
};

export function ColorSwatches({ value, onChange }: Props) {
  return (
    <div className="flex flex-wrap" role="radiogroup" aria-label="Renk">
      {COLORS.map((c) => {
        const selected = c.id === value;
        return (
          <button
            key={c.id}
            type="button"
            role="radio"
            aria-checked={selected}
            aria-label={c.name}
            title={c.name}
            onClick={() => onChange(c.id)}
            className="flex size-11 items-center justify-center"
          >
            <span
              className={cn(
                "size-5 border border-border-strong transition-[outline-color] duration-200",
                selected && "outline-2 outline-offset-2 outline-taba",
              )}
              style={{ backgroundColor: c.swatch }}
            />
          </button>
        );
      })}
    </div>
  );
}

export function ColorDot({ id, className }: { id: ColorId; className?: string }) {
  const c = COLORS.find((x) => x.id === id);
  return (
    <span
      className={cn("inline-block size-3 border border-border-strong", className)}
      style={{ backgroundColor: c?.swatch }}
      title={c?.name}
    />
  );
}
