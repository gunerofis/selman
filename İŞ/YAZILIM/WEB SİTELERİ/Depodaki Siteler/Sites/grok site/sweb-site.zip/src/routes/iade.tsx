import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/legal-page";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/iade")({
  component: Page,
  head: () =>
    pageHead({
      title: "İade",
      description: "14 gün, kullanılmamış. Önizleme metni.",
      path: "/iade",
    }),
});

function Page() {
  return (
    <LegalPage kicker="Hukuki" title="İade">
      <p>
        Teslimden itibaren 14 gün içinde, kullanılmamış ve etiketli ürünler
        iade edilir. Kargo hasarı ayrı değerlendirilir.
      </p>
      <p>
        İade için sipariş numarası ve stok kodu ile yazın. Onaydan sonra ürün
        atölye adresine gönderilir. İnceleme sonrası bedel, ödeme yöntemine
        göre iade edilir.
      </p>
      <p>
        Kişiye özel kesim veya proje siparişleri iade kapsamı dışındadır.
      </p>
    </LegalPage>
  );
}
