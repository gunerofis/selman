import { type FormEvent, useEffect, useMemo, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { cartSubtotal, shippingFor, useCart } from "@/lib/cart";
import { getColor, getProduct } from "@/lib/products";
import { pageHead } from "@/lib/seo";
import { formatPrice } from "@/lib/utils";
import { EmptyHint } from "@/components/qty-control";
import { DemoNotice } from "@/components/demo-notice";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/odeme")({
  component: Checkout,
  head: () =>
    pageHead({
      title: "Ödeme",
      description: "Önizleme. Tahsilat yok. Sipariş tarayıcıda saklanır.",
      path: "/odeme",
    }),
});

const CITIES = [
  "İstanbul",
  "Ankara",
  "İzmir",
  "Bursa",
  "Antalya",
  "Kocaeli",
  "Eskişehir",
  "Diğer",
];

function Checkout() {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  const navigate = useNavigate();
  const lines = useCart((s) => s.lines);
  const clear = useCart((s) => s.clear);
  const subtotal = cartSubtotal(lines);
  const shipping = shippingFor(subtotal);
  const total = subtotal + shipping;
  const [pay, setPay] = useState<"kapida" | "havale">("kapida");
  const [error, setError] = useState("");

  const items = useMemo(
    () =>
      lines
        .map((l) => {
          const p = getProduct(l.sku);
          const c = getColor(l.color);
          if (!p) return null;
          return { ...l, product: p, colorName: c?.name ?? l.color };
        })
        .filter(Boolean),
    [lines],
  );

  if (!ready) {
    return <div className="mx-auto max-w-6xl px-4 py-20 text-sm text-fg-muted">Yükleniyor…</div>;
  }

  if (lines.length === 0) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-16">
        <EmptyHint
          title="Ödenecek bir şey yok"
          body="Sepetiniz boş. Koleksiyondan başlayın."
          action={
            <Link to="/koleksiyon">
              <Button>Koleksiyona git</Button>
            </Link>
          }
        />
      </div>
    );
  }

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    const fd = new FormData(e.currentTarget);
    const name = String(fd.get("name") ?? "").trim();
    const phone = String(fd.get("phone") ?? "").trim();
    const city = String(fd.get("city") ?? "").trim();
    const address = String(fd.get("address") ?? "").trim();
    if (!name || !phone || !city || !address) {
      setError("Lütfen tüm alanları doldurun.");
      return;
    }
    if (!fd.get("kvkk")) {
      setError("KVKK aydınlatmasını işaretleyin.");
      return;
    }
    const order = {
      id: `SW-${Date.now().toString(36).toUpperCase()}`,
      name,
      phone,
      city,
      address,
      pay,
      total,
      items: lines,
      at: new Date().toISOString(),
    };
    try {
      localStorage.setItem("sweb-last-order", JSON.stringify(order));
    } catch {
      /* ignore quota */
    }
    clear();
    void navigate({ to: "/siparis/$id", params: { id: order.id } });
  }

  return (
    <div className="mx-auto grid max-w-6xl gap-10 px-4 py-10 lg:grid-cols-[1fr_340px]">
      <form onSubmit={onSubmit} className="flex flex-col gap-5">
        <h1 className="font-display text-4xl">Teslimat</h1>
        <DemoNotice>
          Önizleme. Tahsilat yok. Sipariş tarayıcıda üretilir, atölyeye iletilmez.
        </DemoNotice>
        <label className="grid gap-1.5 text-sm">
          Ad soyad
          <Input name="name" autoComplete="name" required />
        </label>
        <label className="grid gap-1.5 text-sm">
          Telefon
          <Input name="phone" type="tel" autoComplete="tel" required placeholder="05xx" />
        </label>
        <label className="grid gap-1.5 text-sm">
          Şehir
          <select
            name="city"
            required
            defaultValue="İstanbul"
            className="h-11 border border-border-strong bg-bg-elevated px-3 text-sm"
          >
            {CITIES.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </label>
        <label className="grid gap-1.5 text-sm">
          Adres
          <textarea
            name="address"
            required
            rows={4}
            className="border border-border-strong bg-bg-elevated px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
        </label>
        <fieldset className="grid gap-2">
          <legend className="text-sm">Ödeme (önizleme)</legend>
          <label className="flex h-12 items-center gap-3 border border-border-strong bg-bg-elevated px-3 text-sm">
            <input
              type="radio"
              name="pay"
              checked={pay === "kapida"}
              onChange={() => setPay("kapida")}
            />
            Kapıda ödeme
          </label>
          <label className="flex h-12 items-center gap-3 border border-border-strong bg-bg-elevated px-3 text-sm">
            <input
              type="radio"
              name="pay"
              checked={pay === "havale"}
              onChange={() => setPay("havale")}
            />
            Havale / EFT
          </label>
        </fieldset>
        <label className="flex items-start gap-2 text-sm">
          <input type="checkbox" name="kvkk" required className="mt-1 size-4 shrink-0" />
          <span>
            <Link to="/kvkk" className="underline-offset-2 hover:underline">
              KVKK aydınlatmasını
            </Link>{" "}
            okudum. Bu önizlemede veri tarayıcıda kalır.
          </span>
        </label>
        {error ? <p className="text-sm text-danger">{error}</p> : null}
        <Button type="submit" size="lg">
          Siparişi tamamla · {formatPrice(total)}
        </Button>
      </form>

      <aside className="h-fit border border-dashed border-border bg-bg-elevated p-5">
        <h2 className="font-display text-2xl">Sipariş</h2>
        <ul className="mt-4 space-y-3">
          {items.map((it) =>
            it ? (
              <li key={`${it.sku}-${it.color}`} className="flex justify-between gap-3 text-sm">
                <span>
                  {it.product.name}
                  <span className="block text-xs text-fg-subtle">
                    {it.colorName} × {it.qty}
                  </span>
                </span>
                <span className="tabular-nums">
                  {formatPrice(it.product.price * it.qty)}
                </span>
              </li>
            ) : null,
          )}
        </ul>
        <div className="mt-4 flex justify-between border-t border-border pt-4 text-sm">
          <span>Kargo</span>
          <span>{shipping === 0 ? "Ücretsiz" : formatPrice(shipping)}</span>
        </div>
        <div className="mt-2 flex justify-between text-base">
          <span>Toplam</span>
          <span className="tabular-nums">{formatPrice(total)}</span>
        </div>
      </aside>
    </div>
  );
}
