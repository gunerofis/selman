import { type FormEvent, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import {
  CATEGORIES,
  COLORS,
  PRODUCTS,
  type ColorId,
} from "@/lib/products";
import { pageHead } from "@/lib/seo";
import { ProductWall } from "@/components/product-wall";
import { SeriesCards } from "@/components/series-cards";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Search = { renk?: ColorId };

export const Route = createFileRoute("/")({
  validateSearch: (raw: Record<string, unknown>): Search => ({
    renk: COLORS.some((c) => c.id === raw.renk) ? (raw.renk as ColorId) : undefined,
  }),
  head: () =>
    pageHead({
      title: "Düzen ürünleri",
      description: "Ev ve çalışma alanı için düzen ürünleri. 8 deri renk, örnek fotoğraf.",
      path: "/",
    }),
  component: Home,
});

const WASH = [
  "bg-p-krem",
  "bg-p-gri",
  "bg-p-lacivert",
  "bg-p-taba",
  "bg-p-bordo",
  "bg-p-siyah",
  "bg-p-krem",
  "bg-p-gri",
];

function Home() {
  const { renk } = Route.useSearch();
  const navigate = Route.useNavigate();
  const [mail, setMail] = useState("");

  function onNews(e: FormEvent) {
    e.preventDefault();
    if (!mail.includes("@")) return;
    toast.success("Kaydedildi — bu önizlemede atölyeye gönderilmedi.");
    setMail("");
  }

  return (
    <div>
      <div className="mx-auto max-w-[1400px] px-4">
        <Link
          to="/tasarla"
          className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 border-b border-dashed border-border py-5 hover:text-taba"
        >
          <span className="font-display text-lg">Tasarımınızı gönderin, üretelim</span>
          <span className="text-sm text-fg-muted">
            Anlatın, tahmini ölçü ve fiyat çıksın →
          </span>
        </Link>
      </div>
      <ProductWall
        color={renk}
        onColor={(id) =>
          void navigate({
            search: { renk: id },
            replace: true,
          })
        }
      />

      <section className="border-t border-dashed border-border">
        <div className="mx-auto grid max-w-[1400px] gap-px bg-border sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["Atölye", "İstanbul, Bomonti"],
            ["Teslim", "3–5 iş günü"],
            ["Renk", "8 deri"],
            ["İade", "14 gün"],
          ].map(([k, v]) => (
            <div key={k} className="bg-bg px-5 py-6">
              <p className="font-mono text-xs tracking-wide text-fg-muted uppercase">{k}</p>
              <p className="mt-1 text-sm">{v}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-4 py-16">
        <p className="font-mono text-xs tracking-wide text-fg-muted uppercase">Atölye</p>
        <h2 className="mt-2 font-display text-3xl">Nasıl işliyor</h2>
        <ol className="mt-8 grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["1", "Anlatın", "Aklınızdaki düzeni cümleyle yazın. Form, ölçü, renk — biliyorsanız ekleyin."],
            ["2", "Ölçü çıksın", "İlk fiyat tahmini. Form, milimetre ve birim fiyat döner."],
            ["3", "Yakın stok", "Beklerken katalogdaki benzer parçalar görünür. Hazır ürün de vardır."],
            ["4", "Numune", "Onaylarsanız numune 10–15 iş günü. Elli adet ve üzeri teklif sayfasından."],
          ].map(([n, t, b]) => (
            <li key={n} className="bg-bg-elevated px-5 py-6">
              <p className="font-mono text-xs text-fg-muted">{n}</p>
              <p className="mt-2 font-display text-xl">{t}</p>
              <p className="mt-2 text-sm text-fg-muted">{b}</p>
            </li>
          ))}
        </ol>
        <div className="mt-8">
          <Link to="/tasarla">
            <Button size="lg">Tasarımı gönder</Button>
          </Link>
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-4 py-16">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-mono text-xs tracking-wide text-fg-muted uppercase">Ofis</p>
            <h2 className="mt-2 font-display text-3xl">Masa setleri</h2>
            <p className="mt-2 max-w-xl text-sm text-fg-muted">
              Kompakt, aksesuar, yönetici. Tek renk, tek sepet.
            </p>
          </div>
          <Link to="/setler" className="text-sm text-fg-muted hover:text-taba">
            Tüm setler →
          </Link>
        </div>
        <div className="mt-8">
          <SeriesCards />
        </div>
      </section>

      <section className="mx-auto max-w-[1400px] px-4 py-16">
        <p className="font-mono text-xs tracking-wide text-fg-muted uppercase">Odalar</p>
        <h2 className="mt-2 font-display text-3xl">Kategori</h2>
        <div className="mt-8 grid grid-cols-2 gap-px bg-border sm:grid-cols-4">
          {CATEGORIES.map((c, i) => {
            const items = PRODUCTS.filter((p) => p.category === c.id);
            const cover = items[0];
            return (
              <Link
                key={c.id}
                to="/kategori/$id"
                params={{ id: c.id }}
                className={`${WASH[i % WASH.length]} group flex aspect-square flex-col`}
              >
                {cover ? (
                  <img
                    src={cover.image}
                    alt=""
                    className="min-h-0 w-full flex-1 object-contain p-3 transition-opacity duration-200 group-hover:opacity-90"
                  />
                ) : null}
                <span className="flex items-baseline justify-between gap-2 px-3 pb-3">
                  <span className="text-sm font-medium">{c.name}</span>
                  <span className="font-mono text-xs text-fg-muted">{items.length}</span>
                </span>
              </Link>
            );
          })}
        </div>
      </section>

      <section className="border-t border-dashed border-border">
        <form
          onSubmit={onNews}
          className="mx-auto flex max-w-xl flex-col gap-4 px-4 py-14"
        >
          <p className="font-mono text-xs tracking-wide text-fg-muted uppercase">
            Atölye notları
          </p>
          <h2 className="font-display text-3xl">Yeni parça, yeni renk.</h2>
          <p className="text-sm text-fg-muted">Ayda bir. Fazla değil. Bu önizlemede kayıt gönderilmez.</p>
          <div className="flex flex-col gap-2 sm:flex-row">
            <Input
              type="email"
              required
              value={mail}
              onChange={(e) => setMail(e.target.value)}
              placeholder="ad@firma.com"
              aria-label="E-posta"
              className="flex-1"
            />
            <Button type="submit" size="lg">
              Kaydol
            </Button>
          </div>
        </form>
      </section>
    </div>
  );
}
