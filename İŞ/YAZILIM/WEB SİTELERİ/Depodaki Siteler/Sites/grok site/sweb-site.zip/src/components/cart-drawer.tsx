import { useEffect, useRef } from "react";
import { Link } from "@tanstack/react-router";
import { Trash2, X } from "lucide-react";
import {
  cartCount,
  cartSubtotal,
  shippingFor,
  useCart,
} from "@/lib/cart";
import { FREE_SHIPPING_FROM, getColor, getProduct, productSlug } from "@/lib/products";
import { formatPrice } from "@/lib/utils";
import { ColorDot } from "@/components/color-swatch";
import { QtyControl } from "@/components/qty-control";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

function focusables(root: HTMLElement) {
  return [
    ...root.querySelectorAll<HTMLElement>(
      'a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])',
    ),
  ].filter((el) => !el.hasAttribute("disabled") && el.tabIndex !== -1);
}

export function CartDrawer() {
  const open = useCart((s) => s.drawerOpen);
  const close = useCart((s) => s.closeDrawer);
  const lines = useCart((s) => s.lines);
  const setQty = useCart((s) => s.setQty);
  const remove = useCart((s) => s.remove);
  const subtotal = cartSubtotal(lines);
  const shipping = shippingFor(subtotal);
  const total = subtotal + shipping;
  const remaining = Math.max(0, FREE_SHIPPING_FROM - subtotal);
  const progress = Math.min(100, (subtotal / FREE_SHIPPING_FROM) * 100);
  const panelRef = useRef<HTMLElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const lastFocus = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!open) return;
    lastFocus.current = document.activeElement as HTMLElement | null;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const t = window.setTimeout(() => closeRef.current?.focus(), 20);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        close();
        return;
      }
      if (e.key !== "Tab") return;
      const root = panelRef.current;
      if (!root) return;
      const list = focusables(root);
      if (list.length === 0) return;
      const first = list[0];
      const last = list[list.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.clearTimeout(t);
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
      lastFocus.current?.focus();
    };
  }, [open, close]);

  return (
    <div
      className={cn(
        "fixed inset-0 z-50",
        open ? "pointer-events-auto" : "pointer-events-none",
      )}
      aria-hidden={!open}
    >
      <button
        type="button"
        aria-label="Kapat"
        tabIndex={open ? 0 : -1}
        className={cn(
          "absolute inset-0 bg-bg-deep/40 transition-opacity duration-200",
          open ? "opacity-100" : "opacity-0",
        )}
        onClick={close}
      />
      <aside
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-label="Sepet"
        className={cn(
          "absolute top-0 right-0 flex h-full w-full max-w-md flex-col border-l border-dashed border-border bg-bg-elevated transition-transform duration-200 ease-[cubic-bezier(0.22,1,0.36,1)]",
          open ? "translate-x-0" : "translate-x-full",
        )}
      >
        <div className="flex h-16 items-center justify-between border-b border-dashed border-border px-4">
          <h2 className="font-display text-2xl">Sepet · {cartCount(lines)}</h2>
          <button
            ref={closeRef}
            type="button"
            className="flex size-11 items-center justify-center"
            aria-label="Kapat"
            onClick={close}
          >
            <X className="size-5" />
          </button>
        </div>

        {lines.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
            <p className="font-display text-2xl">Sepet boş</p>
            <p className="text-sm text-fg-muted">Koleksiyondan bir parça ekleyin.</p>
            <Link to="/koleksiyon" onClick={close}>
              <Button>Koleksiyona git</Button>
            </Link>
          </div>
        ) : (
          <>
            <div className="border-b border-border px-4 py-3">
              <div className="h-1 overflow-hidden bg-border">
                <div
                  className="h-full bg-accent transition-[width] duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <p className="mt-2 text-xs text-fg-muted">
                {remaining > 0
                  ? `Ücretsiz kargo için ${formatPrice(remaining)} kaldı`
                  : "Kargo ücretsiz"}
              </p>
            </div>
            <ul className="flex-1 overflow-y-auto px-4">
              {lines.map((line) => {
                const p = getProduct(line.sku);
                if (!p) return null;
                const color = getColor(line.color);
                return (
                  <li
                    key={`${line.sku}-${line.color}`}
                    className="flex gap-3 border-b border-dashed border-border py-4"
                  >
                    <Link
                      to="/urun/$sku"
                      params={{ sku: productSlug(p) }}
                      search={{ renk: line.color }}
                      onClick={close}
                      className="size-20 shrink-0 overflow-hidden bg-bg-wash"
                    >
                      <img src={p.image} alt="" className="size-full object-contain" />
                    </Link>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <Link
                          to="/urun/$sku"
                          params={{ sku: productSlug(p) }}
                          search={{ renk: line.color }}
                          onClick={close}
                          className="font-display text-lg leading-tight"
                        >
                          {p.name}
                        </Link>
                        <button
                          type="button"
                          className="flex size-9 shrink-0 items-center justify-center text-fg-muted hover:text-danger"
                          aria-label="Kaldır"
                          onClick={() => remove(line.sku, line.color)}
                        >
                          <Trash2 className="size-4" />
                        </button>
                      </div>
                      <p className="mt-1 flex items-center gap-2 text-xs text-fg-muted">
                        <ColorDot id={line.color} />
                        {color?.name}
                      </p>
                      <div className="mt-2 flex items-center justify-between">
                        <QtyControl
                          value={line.qty}
                          onChange={(n) => setQty(line.sku, line.color, n)}
                        />
                        <span className="font-mono text-sm">
                          {formatPrice(p.price * line.qty)}
                        </span>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
            <div className="border-t border-border p-4">
              <div className="mb-3 flex justify-between text-sm">
                <span className="text-fg-muted">Toplam</span>
                <span className="tabular-nums">{formatPrice(total)}</span>
              </div>
              <Link to="/odeme" onClick={close} className="block">
                <Button className="w-full" size="lg">
                  Ödemeye geç
                </Button>
              </Link>
              <Link
                to="/sepet"
                onClick={close}
                className="mt-3 block text-center text-sm text-fg-muted hover:text-fg"
              >
                Sepet sayfası
              </Link>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}
