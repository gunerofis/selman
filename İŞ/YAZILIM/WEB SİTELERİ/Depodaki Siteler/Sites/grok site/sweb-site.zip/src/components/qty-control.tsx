import { Button } from "@/components/ui/button";

export function QtyControl({
  value,
  onChange,
}: {
  value: number;
  onChange: (n: number) => void;
}) {
  return (
    <div className="inline-flex h-11 items-center border border-border-strong">
      <Button
        variant="ghost"
        size="icon"
        className="size-11 rounded-none"
        aria-label="Azalt"
        onClick={() => onChange(Math.max(1, value - 1))}
      >
        −
      </Button>
      <span className="w-8 text-center text-sm tabular-nums">{value}</span>
      <Button
        variant="ghost"
        size="icon"
        className="size-11 rounded-none"
        aria-label="Arttır"
        onClick={() => onChange(value + 1)}
      >
        +
      </Button>
    </div>
  );
}

export function EmptyHint({
  title,
  body,
  action,
}: {
  title: string;
  body: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="mx-auto max-w-lg border border-dashed border-border bg-bg-elevated px-6 py-16 text-center">
      <h2 className="font-display text-3xl">{title}</h2>
      <p className="mx-auto mt-3 max-w-md text-sm text-fg-muted">{body}</p>
      {action ? <div className="mt-6 flex justify-center">{action}</div> : null}
    </div>
  );
}
