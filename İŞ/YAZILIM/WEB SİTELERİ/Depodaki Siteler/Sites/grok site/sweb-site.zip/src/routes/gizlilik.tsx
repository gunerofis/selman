import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/legal-page";
import { BRAND } from "@/lib/brand";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/gizlilik")({
  component: Page,
  head: () =>
    pageHead({
      title: "Gizlilik politikası",
      description: "Önizlemede veri tarayıcıda kalır.",
      path: "/gizlilik",
    }),
});

function Page() {
  return (
    <LegalPage kicker="Hukuki" title="Gizlilik politikası">
      <p>
        Sipariş ve iletişim formlarında ad, e-posta, telefon ve teslimat adresi
        alınır. Bu veriler siparişi işlemek ve size dönüş yapmak için kullanılır.
      </p>
      <p>
        Ödeme bilgisi sitede saklanmaz. Kapıda ödeme ve havale seçenekleri
        atölye tarafından ayrıca teyit edilir.
      </p>
      <p>
        Tarayıcıda sepet ve favori listesi yerel olarak tutulur; başka cihaza
        taşınmaz. İstemezseniz tarayıcı verisini silebilirsiniz.
      </p>
      <p>
        Bu önizlemede sipariş ve form verisi tarayıcıda kalır; sunucuya
        kaydedilmez. Canlı tahsilat yoktur.
      </p>
      <p>Sorular için {BRAND.email}.</p>
    </LegalPage>
  );
}
