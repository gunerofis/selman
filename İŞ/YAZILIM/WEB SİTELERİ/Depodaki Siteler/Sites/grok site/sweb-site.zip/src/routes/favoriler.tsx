import { createFileRoute, Link } from "@tanstack/react-router";
import { usePrefs, wishedProducts } from "@/lib/prefs";
import { useHydrated } from "@/lib/use-hydrated";
import { specGrams, productSlug } from "@/lib/products";
import { pageHead } from "@/lib/seo";
import { formatPrice } from "@/lib/utils";
import { ProductCard } from "@/components/product-card";
import { EmptyHint } from "@/components/qty-control";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart";

export const Route = createFileRoute("/favoriler")({
  component: Favorites,
  head: () =>
    pageHead({
      title: "Favoriler",
      description: "Kayıtlı parçalar. Karşılaştırma listesi tarayıcıda.",
      path: "/favoriler",
    }),
});

function Favorites() {
  const ready = useHydrated();
  const wishlist = usePrefs((s) => s.wishlist);
  const items = ready ? wishedProducts(wishlist) : [];
  const add = useCart((s) => s.add);

  if (!ready) {
    return <div className="mx-auto max-w-6xl px-4 py-20 text-sm text-fg-muted">Yükleniyor…</div>;
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-6xl px-4">
        <EmptyHint
          title="Favori yok"
          body="Bir parçanın kalbine dokunun — listeniz burada durur."
          action={
            <Link to="/koleksiyon">
              <Button>Koleksiyona git</Button>
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <p className="text-xs tracking-[0.28em] text-fg-muted uppercase">Kayıtlı</p>
      <h1 className="mt-2 font-display text-5xl">Favoriler</h1>
      <p className="mt-3 text-sm text-fg-muted">{items.length} parça · tarayıcıda tutulur</p>
      {items.length >= 2 ? (
        <div className="mt-8 overflow-x-auto border border-dashed border-border">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="bg-bg-wash font-mono text-[11px] tracking-wide text-fg-muted uppercase">
              <tr>
                <th className="px-3 py-2 font-normal">Parça</th>
                <th className="px-3 py-2 font-normal">Oda</th>
                <th className="px-3 py-2 font-normal">Ölçü</th>
                <th className="px-3 py-2 font-normal">Ağırlık</th>
                <th className="px-3 py-2 font-normal">Fiyat</th>
                <th className="px-3 py-2 font-normal" />
              </tr>
            </thead>
            <tbody>
              {items.map((p) => {
                const olcu = p.specs.find((s) => s.label === "Dış ölçü")?.value ?? "—";
                return (
                  <tr key={p.sku} className="border-t border-dashed border-border">
                    <td className="px-3 py-3">
                      <Link
                        to="/urun/$sku"
                        params={{ sku: productSlug(p) }}
                        className="font-medium hover:text-taba"
                      >
                        {p.name}
                      </Link>
                      <span className="mt-0.5 block font-mono text-[11px] text-fg-muted">
                        {p.sku}
                      </span>
                    </td>
                    <td className="px-3 py-3 text-fg-muted">{p.category}</td>
                    <td className="px-3 py-3 font-mono text-[13px]">{olcu}</td>
                    <td className="px-3 py-3 font-mono text-[13px]">{specGrams(p)}</td>
                    <td className="px-3 py-3 tabular-nums">{formatPrice(p.price)}</td>
                    <td className="px-3 py-3 text-right">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => add(p.sku, "espresso", 1)}
                      >
                        Sepete ekle
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : null}
      <div className="mt-8 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((p) => (
          <ProductCard key={p.sku} product={p} />
        ))}
      </div>
    </div>
  );
}
