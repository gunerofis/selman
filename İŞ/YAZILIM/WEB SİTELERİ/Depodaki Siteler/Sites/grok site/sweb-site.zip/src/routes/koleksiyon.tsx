import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { CATEGORIES, COLORS, PRODUCTS, SERIES, getSeries, matchesQuery, type CategoryId, type ColorId, type SeriesId } from "@/lib/products";
import { pageHead } from "@/lib/seo";
import { ProductCard } from "@/components/product-card";
import { SeriesCard, SeriesCards } from "@/components/series-cards";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

type SortId = "onerilen" | "fiyat-asc" | "fiyat-desc" | "ad";

type Search = { kategori?: CategoryId; q?: string; sirala?: SortId; seri?: SeriesId };

export const Route = createFileRoute("/koleksiyon")({
  validateSearch: (raw: Record<string, unknown>): Search => ({
    kategori: CATEGORIES.some((c) => c.id === raw.kategori)
      ? (raw.kategori as CategoryId)
      : undefined,
    q: typeof raw.q === "string" ? raw.q : undefined,
    sirala: ["onerilen", "fiyat-asc", "fiyat-desc", "ad"].includes(String(raw.sirala))
      ? (raw.sirala as SortId)
      : undefined,
    seri: SERIES.some((s) => s.id === raw.seri) ? (raw.seri as SeriesId) : undefined,
  }),
  head: () =>
    pageHead({
      title: "Ürünler",
      description: "Bütün parçalar. İsim, stok kodu veya iş: şarj, baharat, gözlük.",
      path: "/koleksiyon",
    }),
  component: Shop,
});

function Shop() {
  const { kategori, q, sirala, seri } = Route.useSearch();
  const navigate = Route.useNavigate();
  const [color, setColor] = useState<ColorId | "all">("all");
  const [query, setQuery] = useState(q ?? "");
  const sort: SortId = sirala ?? "onerilen";

  useEffect(() => {
    setQuery(q ?? "");
  }, [q]);

  const list = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase("tr");
    const filtered = PRODUCTS.filter((p) => {
      if (kategori && p.category !== kategori) return false;
      if (seri && p.series !== seri) return false;
      if (!needle) return true;
      return matchesQuery(p, needle);
    });
    const copy = [...filtered];
    if (sort === "fiyat-asc") copy.sort((a, b) => a.price - b.price);
    if (sort === "fiyat-desc") copy.sort((a, b) => b.price - a.price);
    if (sort === "ad") copy.sort((a, b) => a.name.localeCompare(b.name, "tr"));
    return copy;
  }, [kategori, query, sort, seri]);

  const catName = CATEGORIES.find((c) => c.id === kategori)?.name;
  const seriesMeta = getSeries(seri);
  const colorId = color === "all" ? undefined : color;

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-10">
      <p className="font-mono text-xs tracking-wide text-fg-muted uppercase">Ürünler</p>
      <h1 className="mt-2 font-display text-4xl sm:text-5xl">
        {seriesMeta?.name ?? catName ?? "Bütün parçalar"}
      </h1>
      <p className="mt-3 max-w-xl text-sm text-fg-muted">
        {seriesMeta
          ? `${seriesMeta.blurb} ${list.length} parça.`
          : `${PRODUCTS.length} parça, sekiz deri renk. Fotoğraflar örnek; seçilen renk zemini boyar.`}
      </p>

      <div className="mt-8 flex flex-col gap-5">
        <Input
          value={query}
          onChange={(e) => {
            const v = e.target.value;
            setQuery(v);
            void navigate({
              search: (prev) => ({ ...prev, q: v || undefined }),
              replace: true,
            });
          }}
          placeholder="şarj, baharat, gözlük, dizüstü"
          aria-label="Koleksiyonda ara"
        />
        <div>
          <p className="mb-2 font-mono text-xs text-fg-muted">Oda</p>
          <div className="flex flex-wrap gap-2">
            <FilterChip
              active={!kategori}
              onClick={() =>
                void navigate({ search: (s) => ({ ...s, kategori: undefined, seri: undefined }) })
              }
            >
              Tümü
            </FilterChip>
            {CATEGORIES.map((c) => (
              <FilterChip
                key={c.id}
                active={kategori === c.id}
                onClick={() =>
                  void navigate({
                    search: (s) => ({
                      ...s,
                      kategori: c.id,
                      seri: c.id === "ofis" ? s.seri : undefined,
                    }),
                  })
                }
              >
                {c.name}
              </FilterChip>
            ))}
          </div>
        </div>
        {kategori === "ofis" ? (
          <div>
            <p className="mb-2 font-mono text-xs text-fg-muted">Set</p>
            <div className="flex flex-wrap gap-2">
              <FilterChip
                active={!seri}
                onClick={() => void navigate({ search: (s) => ({ ...s, seri: undefined }) })}
              >
                Tüm masa
              </FilterChip>
              {SERIES.map((s) => (
                <FilterChip
                  key={s.id}
                  active={seri === s.id}
                  onClick={() =>
                    void navigate({
                      search: (prev) => ({ ...prev, seri: prev.seri === s.id ? undefined : s.id }),
                    })
                  }
                >
                  {s.name}
                </FilterChip>
              ))}
            </div>
          </div>
        ) : null}
        <div>
          <p className="mb-2 font-mono text-xs text-fg-muted">Renk</p>
          <div className="flex flex-wrap items-center">
            <button
              type="button"
              onClick={() => setColor("all")}
              className={cn(
                "h-11 border px-3 font-mono text-xs",
                color === "all" ? "border-fg bg-fg text-bg-elevated" : "border-border-strong text-fg-muted",
              )}
            >
              Hepsi
            </button>
            {COLORS.map((c) => (
              <button
                key={c.id}
                type="button"
                title={c.name}
                aria-label={c.name}
                onClick={() => setColor(c.id)}
                className="flex size-11 items-center justify-center"
              >
                <span
                  className={cn(
                    "size-5 border border-border-strong",
                    color === c.id && "outline-2 outline-offset-2 outline-taba",
                  )}
                  style={{ backgroundColor: c.swatch }}
                />
              </button>
            ))}
          </div>
        </div>
        <label className="flex items-center gap-2 text-sm text-fg-muted">
          Sırala
          <select
            value={sort}
            onChange={(e) =>
              void navigate({
                search: (s) => ({
                  ...s,
                  sirala: e.target.value === "onerilen" ? undefined : (e.target.value as SortId),
                }),
              })
            }
            className="h-11 border border-border-strong bg-bg-elevated px-3 text-sm text-fg"
          >
            <option value="onerilen">Önerilen</option>
            <option value="fiyat-asc">Fiyat: artan</option>
            <option value="fiyat-desc">Fiyat: azalan</option>
            <option value="ad">İsim</option>
          </select>
        </label>
      </div>

      {kategori === "ofis" && !seri ? (
        <div className="mt-10">
          <p className="font-mono text-xs tracking-wide text-fg-muted uppercase">Masa setleri</p>
          <h2 className="mt-1 font-display text-2xl">Üç seri</h2>
          <div className="mt-5">
            <SeriesCards color={colorId} />
          </div>
        </div>
      ) : null}

      {seriesMeta ? (
        <div className="mt-10 max-w-xl">
          <SeriesCard id={seriesMeta.id} color={colorId} />
        </div>
      ) : null}

      <p className="mt-8 font-mono text-sm text-fg-muted">
        {list.length} parça
        {color !== "all" ? ` · ${COLORS.find((c) => c.id === color)?.name}` : ""}
      </p>

      {list.length === 0 ? (
        <p className="py-16 text-center text-fg-muted">Eşleşen parça yok.</p>
      ) : (
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {list.map((p) => (
            <ProductCard
              key={p.sku}
              product={p}
              color={color === "all" ? undefined : color}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-11 border px-3 text-sm transition-colors duration-200",
        active
          ? "border-fg bg-fg text-bg-elevated"
          : "border-border-strong text-fg-muted hover:border-fg hover:text-fg",
      )}
    >
      {children}
    </button>
  );
}
