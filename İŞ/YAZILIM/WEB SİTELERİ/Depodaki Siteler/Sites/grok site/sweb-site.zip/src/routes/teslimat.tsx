import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/legal-page";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/teslimat")({
  component: Page,
  head: () =>
    pageHead({
      title: "Teslimat",
      description: "Hazır stok 3–5 iş günü. Bu sayfa önizleme metnidir.",
      path: "/teslimat",
    }),
});

function Page() {
  return (
    <LegalPage kicker="Hukuki" title="Teslimat">
      <p>
        Siparişler İstanbul atölyesinden 3–5 iş günü içinde kargoya verilir.
        Stok dışı veya proje siparişlerinde süre ayrıca yazılır.
      </p>
      <p>
        5.000 ₺ üzeri Türkiye içi kargo ücretsizdir. Altındaki siparişlerde
        kargo bedeli sepet özetinde görünür.
      </p>
      <p>
        Bu metin önizleme içindir. Canlı tahsilat ve kargo çıkışı yoktur.
      </p>
    </LegalPage>
  );
}
